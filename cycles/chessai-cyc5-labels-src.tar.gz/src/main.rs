use std::fmt::Write as _;
use std::path::{Path, PathBuf};
use std::time::Instant;

use anyhow::{Context, Result, bail};
use clap::{Parser, Subcommand, ValueEnum};
use rand::rngs::StdRng;
use rand::{RngExt, SeedableRng};
use shakmaty::uci::UciMove;
use shakmaty::{CastlingMode, Chess, Position};

use chessai::bdd::Bdd;
use chessai::bdt::Bdt;
use chessai::calibration::Calibration;
use chessai::delegation::{self, DelegationParams, ErrorMeasure, ErrorTarget, NodeKind, NodeModel, RouteTarget, SplitRule};
use chessai::classifier::{Classifier, Uniform};
use chessai::cnbp::Cnbp;
use chessai::logreg::Logreg;
use chessai::moe::Moe;
use chessai::encoding::{self, CATEGORIES, Encoded};
use chessai::fm::Fm;
use chessai::ht::{Criterion, Ht, HtParams};
use chessai::game::Game;
use chessai::games;
use chessai::game::GameResult;
use chessai::player::{self, Player, Policy};
use chessai::search::Value;
use chessai::selfplay;
use chessai::tan::{self, Tan, TanOptions};
use chessai::tournament;

#[derive(Parser)]
#[command(about = "chessai: categorical Bayesian chess models")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Play a match between two players, alternating colours, and report the
    /// score and an Elo difference estimate. A player is `cnbp:PATH`,
    /// `bdt:PATH`, `bdd:PATH` (a saved model) or `rand`.
    Arena {
        a: String,
        b: String,
        #[arg(long, default_value_t = 1000)]
        games: usize,
        #[arg(long, value_enum, default_value_t = Policy::WldScoreJitter10)]
        a_policy: Policy,
        #[arg(long, value_enum, default_value_t = Policy::WldScoreJitter10)]
        b_policy: Policy,
        /// Softmax temperature for the wld-score-softmax policy.
        #[arg(long, default_value_t = 0.01)]
        temperature: f64,
        /// Predict from cached probabilities (faster) instead of raw counts.
        #[arg(long)]
        use_probs: bool,
        /// Random seed; chosen and printed if not given.
        #[arg(long)]
        seed: Option<u64>,
        /// Also write the games, in the self-play round format.
        #[arg(long)]
        out: Option<PathBuf>,
        /// Search depth of player A in plies (0: score the moves directly;
        /// 1 or more: alpha-beta search, needs a log-odds policy or an
        /// expected-score one: wld-score and its jittered versions).
        #[arg(long, default_value_t = 0)]
        a_depth: u32,
        #[arg(long, default_value_t = 0)]
        b_depth: u32,
        /// How player A's search values positions (needs --a-depth).
        #[arg(long, value_enum, default_value_t = Value::LogOdds)]
        a_value: Value,
        #[arg(long, value_enum, default_value_t = Value::LogOdds)]
        b_value: Value,
        /// Calibration of player A's probabilities for the score value,
        /// SLOPE_WINNER,SLOPE_DECISIVE,OFFSET_WHITE,OFFSET_BLACK as printed by
        /// `eval-loss --fit-calibration`.
        #[arg(long)]
        a_calibration: Option<String>,
        #[arg(long)]
        b_calibration: Option<String>,
    },

    /// Rate players by repeated double round-robin tournaments: in each,
    /// every player meets every other once with each colour. PLAYERS lists
    /// one player per line as NAME DEPTH SPEC (SPEC as for `arena`; lines
    /// starting with # are comments). After every tournament its games are
    /// appended to OUT/games.csv, and the rating list (ratings.md/.csv), the
    /// head-to-head table (head_to_head.md/.csv) and the ratings after each
    /// tournament (elo_history.csv) are rewritten. Running again with the
    /// same OUT continues where it stopped, or only rewrites the tables;
    /// players added to PLAYERS first play the earlier tournaments' games
    /// (unless --no-catch-up). Every player with games in OUT/games.csv must
    /// be in PLAYERS or in --retired.
    Tournament {
        players: PathBuf,
        out: PathBuf,
        /// Tournaments to have played in all, counting those already in OUT.
        #[arg(long, default_value_t = 50)]
        tournaments: u64,
        #[arg(long, value_enum, default_value_t = Policy::LogOddsSoftmax)]
        policy: Policy,
        /// Softmax temperature of the policy.
        #[arg(long, default_value_t = 0.1)]
        temperature: f64,
        /// Predict from cached probabilities (faster) instead of raw counts.
        #[arg(long)]
        use_probs: bool,
        /// Random seed; keep it when continuing a run.
        #[arg(long, default_value_t = 1)]
        seed: u64,
        /// K-factor of the running Elo, per game.
        #[arg(long, default_value_t = 8.0)]
        k: f64,
        /// Virtual draws per pairing in the maximum-likelihood ratings, so
        /// perfect scores give finite ratings. 0 for pure maximum likelihood:
        /// players whose rating does not exist (a perfect or a zero score, or
        /// no results linking them both ways to the anchor) are listed as
        /// unrated.
        #[arg(long, default_value_t = 1.0)]
        prior_draws: f64,
        /// The player rated 0 in the tables (default: the field's mean).
        #[arg(long)]
        anchor: Option<String>,
        /// Don't play the earlier tournaments' games for the players added
        /// to PLAYERS since: each tournament is a round-robin of the players
        /// listed at the time.
        #[arg(long)]
        no_catch_up: bool,
        /// Retired players, listed as in PLAYERS: they play no more games,
        /// but their games in OUT/games.csv stay in the ratings, where they
        /// are marked as retired. Their models are not loaded.
        #[arg(long)]
        retired: Option<PathBuf>,
        /// Also write every game played, to train on: the game of tournament
        /// T (from 0, as in games.csv) between WHITE and BLACK (the players'
        /// names) goes to DIR/round{T}/{WHITE}~{BLACK}/, in the self-play
        /// round format (its positions in white_wins.games, black_wins.games
        /// or draws.games by result, its moves in human.games). `train DIR`
        /// trains on whole tournaments, one per round; for a chosen subset,
        /// make round directories of links to the chosen games' directories.
        /// Games already in OUT/games.csv are not replayed, so not saved.
        #[arg(long)]
        save_games: Option<PathBuf>,
    },

    /// Train a model by self-play: each round plays games in parallel, writes
    /// them in the self_play.py format, and trains the model on them.
    SelfPlay {
        /// Directory for round{N}/ game files, results.txt and models.
        out: PathBuf,
        #[arg(long, value_enum, default_value_t = ModelKind::Cnbp)]
        model: ModelKind,
        #[arg(long, default_value_t = 10)]
        rounds: u64,
        #[arg(long, default_value_t = 1000)]
        games: usize,
        #[arg(long, value_enum, default_value_t = Policy::WldScoreJitter10)]
        policy: Policy,
        /// Softmax temperature for the wld-score-softmax policy.
        #[arg(long, default_value_t = 0.01)]
        temperature: f64,
        /// Random seed; chosen and printed if not given.
        #[arg(long)]
        seed: Option<u64>,
        /// Worker threads for playing; defaults to the number of cores.
        #[arg(long)]
        threads: Option<usize>,
        /// Instead of playing itself, version N plays version N-1 each round
        /// (round 0: the untrained model plays itself). Records version N's
        /// score in ladder.csv.
        #[arg(long)]
        vs_previous: bool,
        /// Don't write each round's games to disk (they take ~50 MB per
        /// 1000 games); models, results.txt and ladder.csv are still written.
        #[arg(long)]
        no_games: bool,
        /// Search depth for choosing moves (0: score the moves directly; 1 or
        /// more: alpha-beta search, needs a log-odds policy or an
        /// expected-score one: wld-score and its jittered versions, which
        /// score each move by the expected score at the end of its principal
        /// variation).
        #[arg(long, default_value_t = 0)]
        depth: u32,
        /// Label each position with the outcome a search this deep by the
        /// model expects from it, instead of the game's result: the result
        /// if the principal variation ends the game, else the probabilities
        /// the model predicts for its last position (at depth 0, for the
        /// position itself), calibrated on the round's results.
        #[arg(long)]
        label_depth: Option<u32>,
        /// With --label-depth: the weight of the game's result in the label,
        /// the rest being the search's.
        #[arg(long, default_value_t = 0.0)]
        label_result: f64,
        /// With --label-depth: search with this fixed model (`cnbp:PATH`,
        /// `bdt:PATH`, `bdd:PATH`) instead of the model being trained.
        #[arg(long)]
        label_model: Option<String>,
        /// After each round's training, divide the model's counts (CNBP) or
        /// AdaGrad sums (LR, MoE) by this, so older rounds' games count less
        /// (1: all rounds alike).
        #[arg(long, default_value_t = 1.0)]
        round_forget: f64,
        /// After round N's training, also divide the counts or sums by
        /// ((N+2)/(N+1))^this, so the games of round s weigh ((s+1)/(N+1))^this
        /// at round N: rounds fade with the run's age, with no time scale to
        /// choose. A start model's games count as the round before the first
        /// (0: off).
        #[arg(long, default_value_t = 0.0)]
        age_forget: f64,
        /// Continue the run in OUT from its last saved model, as if it had
        /// not stopped (give the same options and seed; --rounds counts from
        /// the run's start). Trees resume from the state files of their last
        /// two versions (see --keep-states); a mixture from round 2 on.
        #[arg(long)]
        resume: bool,
        /// Trees also save their whole training state beside each model, as
        /// {model}N.state, for --resume (see `state`); keep the last this
        /// many (0: all). --resume needs the last 2.
        #[arg(long, default_value_t = 2)]
        keep_states: u64,
        /// Start from this saved model instead of an untrained one: a CNBP
        /// file for cnbp, an LR file for lr and moe (as every expert), a file
        /// of the --leaf kind for bdt and bdd (as the root leaf).
        #[arg(long, conflicts_with = "resume")]
        init: Option<PathBuf>,
        #[command(flatten)]
        params: ModelArgs,
    },

    /// Train a model on existing round directories (from self-play, a ladder,
    /// an arena or `tournament --save-games`) instead of its own games. Round
    /// N's positions are shuffled and trained on, then the model is saved as
    /// {model}{N+1}.model (a tree's last also as {model}{N+1}.state, for
    /// --start).
    Train {
        /// Directory containing round0/, round1/, ..., each holding positions
        /// in the round format or game directories (`tournament
        /// --save-games`), whose positions are trained on together.
        games: PathBuf,
        /// Directory for the saved models.
        out: PathBuf,
        #[arg(long, value_enum, default_value_t = ModelKind::Cnbp)]
        model: ModelKind,
        /// Number of rounds to train on, starting from round0.
        #[arg(long, default_value_t = 10)]
        rounds: u64,
        /// Seed for shuffling each round's positions.
        #[arg(long, default_value_t = 0)]
        seed: u64,
        /// Train this saved model further instead of an untrained one: a
        /// model file of the --model kind for cnbp, lr, fm and moe (forgotten
        /// by --init-forget), the state file saved beside a tree's model for
        /// bdt, bdd and ht ({model}N.state, by self-play or train; give the
        /// options it was trained with), for tan its state file or a model
        /// file with its state file beside it (forgotten by --init-forget). --rounds still counts GAMES' rounds
        /// from round0, and the model after round N is still saved as
        /// {model}{N+1}.model, whatever the start model's number.
        #[arg(long)]
        start: Option<PathBuf>,
        /// Label each position with the outcome a search this deep by the
        /// model, as it starts the round, expects from it (as self-play's
        /// --label-depth), calibrated on the round's results, instead of the
        /// game's result. lr only; the round must be game directories with
        /// their moves (human.games), as `tournament --save-games` writes.
        #[arg(long)]
        label_depth: Option<u32>,
        /// With --label-depth: the weight of the game's result in the label,
        /// the rest being the search's.
        #[arg(long, default_value_t = 0.0)]
        label_result: f64,
        /// With --label-depth: search with this fixed model (a spec, as
        /// self-play's --label-model) instead of the model being trained.
        #[arg(long)]
        label_model: Option<String>,
        #[command(flatten)]
        params: ModelArgs,
    },

    /// Replay chosen games of a tournament exactly. PLAYERS is the
    /// tournament's players in their order (NAME DEPTH SPEC, as for
    /// `tournament`); GAMES lists one game per line as T WHITE BLACK. Each is
    /// played with the tournament's seed for it, derive_seed(SEED, T, g), g
    /// its pairing's index, saved to OUT/round{T}/{WHITE}~{BLACK}/, and
    /// printed as T,WHITE,BLACK,RESULT,PLIES (as in games.csv).
    ReplayGames {
        players: PathBuf,
        games: PathBuf,
        out: PathBuf,
        #[arg(long, value_enum, default_value_t = Policy::LogOddsSoftmax)]
        policy: Policy,
        #[arg(long, default_value_t = 0.1)]
        temperature: f64,
        #[arg(long)]
        use_probs: bool,
        #[arg(long, default_value_t = 1)]
        seed: u64,
    },

    /// Play games with a model and report, over the positions reached, how
    /// often jitter10 and softmax at each temperature would play something
    /// other than the top-scored move, and the gap between the top two moves.
    PolicyStats {
        /// `cnbp:PATH`, `bdt:PATH` or `bdd:PATH`.
        model: String,
        #[arg(long, default_value_t = 200)]
        games: usize,
        /// Policy used to play the games that provide the positions.
        #[arg(long, value_enum, default_value_t = Policy::WldScoreJitter10)]
        policy: Policy,
        #[arg(long, default_value_t = 0.01)]
        temperature: f64,
        /// Temperatures to report.
        #[arg(long, value_delimiter = ',', default_value = "0.001,0.003,0.01,0.03,0.1")]
        temperatures: Vec<f64>,
        #[arg(long)]
        use_probs: bool,
        #[arg(long, default_value_t = 1)]
        seed: u64,
    },

    /// Compare a model's predicted probabilities with actual outcomes on
    /// labelled positions (a round directory), bucketed by prediction.
    Calibration {
        /// `cnbp:PATH`, `bdt:PATH` or `bdd:PATH`.
        model: String,
        /// Round directory with white_wins/black_wins/draws.games.
        games: PathBuf,
        #[arg(long)]
        use_probs: bool,
    },

    /// Score a model's predictions on labelled positions (a round directory):
    /// mean log-loss, mean absolute error, and log-loss of who won among
    /// decisive positions.
    EvalLoss {
        /// `cnbp:PATH`, `bdt:PATH` or `bdd:PATH`.
        model: String,
        games: PathBuf,
        #[arg(long)]
        use_probs: bool,
        /// Also fit a calibration of the model's probabilities to these
        /// positions (see `calibration`) and report its log-loss.
        #[arg(long)]
        fit_calibration: bool,
        /// Report the log-loss with this calibration.
        #[arg(long)]
        calibration: Option<String>,
        /// Score only the positions this delegation model (`bdt:PATH` or
        /// `bdd:PATH`) routes to leaf --leaf.
        #[arg(long, requires = "leaf")]
        routed_by: Option<String>,
        /// See --routed-by: the leaf's node index, as `leaves` names it.
        #[arg(long, requires = "routed_by")]
        leaf: Option<usize>,
    },

    /// Write each leaf of a tree (`bdt:PATH`, `bdd:PATH` or `ht:PATH`) to
    /// OUT/leaf{N}.model, N being its node index, as a standalone CNBP or LR
    /// model (load it as `cnbp:` or `lr:`).
    Leaves {
        model: String,
        out: PathBuf,
        #[arg(long)]
        use_probs: bool,
    },

    /// How well a tree's routers route (`bdt:PATH`), on the decisive positions
    /// of labelled games (a round directory). For each delegator and each
    /// child it sends positions to: the winner log-loss of every child's
    /// subtree on those positions, with the tree's log-odds recalibrated by
    /// one scale and offset fitted here. A row whose smallest loss is not its
    /// own child's sends positions to a child that predicts them worse than a
    /// sibling; the regret is what sending each row to its best child would
    /// save. Then the pairs of leaves whose log-odds differ least over all the
    /// positions (near-duplicates).
    Routing {
        model: String,
        games: PathBuf,
        #[arg(long)]
        use_probs: bool,
    },

    /// Measure how well models rank the legal moves of a position. Positions
    /// are sampled from games played by SOURCE; every legal move is valued by
    /// playing PLAYOUTS games from it (SOURCE plays both sides), and each
    /// model ranks the moves by log-odds for the side to move.
    RankTest {
        /// Model playing the sampling games and the playouts (`cnbp:PATH`, ...).
        source: String,
        /// Models to test.
        models: Vec<String>,
        #[arg(long, default_value_t = 200)]
        positions: usize,
        #[arg(long, default_value_t = 50)]
        playouts: usize,
        #[arg(long, value_enum, default_value_t = Policy::WldScoreJitter10)]
        playout_policy: Policy,
        #[arg(long, default_value_t = 1)]
        seed: u64,
        #[arg(long)]
        use_probs: bool,
    },

    /// Replay games dumped by rs/bench/dump_python_games.py and compare legal
    /// moves, encodings and game results with the Python implementation.
    Xcheck { file: PathBuf },

    /// Play random games, encoding every legal move's resulting position the
    /// way the self-play scripts do, and report half-moves per second.
    BenchMovegen {
        #[arg(long, default_value_t = 300)]
        games: usize,
        #[arg(long, default_value_t = 1)]
        seed: u64,
    },

    /// Train a CNBP on a games directory, save it, and predict every training
    /// position. Same inputs and outputs as rs/bench/cnbp_bench.c.
    BenchCnbp {
        games_dir: PathBuf,
        model_out: PathBuf,
        predictions_out: PathBuf,
        #[arg(long, default_value_t = 1.0)]
        alpha: f64,
        #[arg(long)]
        use_probs: bool,
        /// Times to repeat training and prediction, for more stable timing.
        #[arg(long, default_value_t = 10)]
        reps: usize,
    },

    /// Train a BDT on a games directory, save it, and predict every training
    /// position. Same inputs and outputs as rs/bench/bdt_bench.c.
    BenchBdt {
        games_dir: PathBuf,
        model_out: PathBuf,
        predictions_out: PathBuf,
        #[arg(long, default_value_t = 2)]
        branch_factor: usize,
        #[arg(long, default_value_t = 2000)]
        split_threshold: u32,
        #[arg(long, default_value_t = 20)]
        split_limit: u32,
        #[arg(long, default_value_t = 10.0)]
        forget_factor: f64,
        #[arg(long, default_value_t = 1.0)]
        alpha: f64,
        #[arg(long)]
        use_probs: bool,
        #[arg(long, default_value_t = 3)]
        reps: usize,
    },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum)]
enum ModelKind {
    Cnbp,
    Bdt,
    /// Bayesian delegation DAG: a BDT whose delegators can split too. Saved
    /// in the BDT file format; load it as `bdd:PATH`.
    Bdd,
    /// Logistic regression over the same features (not naive Bayes); load
    /// it as `lr:PATH`.
    Lr,
    /// Mixture of logistic-regression experts with a logistic-regression
    /// gate; load it as `moe:PATH`.
    Moe,
    /// Factorization machine: logistic regression plus learned pairwise
    /// interactions of the features; load it as `fm:PATH`.
    Fm,
    /// Hoeffding tree: one feature-value test per internal node, CNBP or LR
    /// leaves (--leaf), split when the Hoeffding bound allows; load it as
    /// `ht:PATH`.
    Ht,
    /// Tree-augmented naive Bayes: CNBP whose features each also condition
    /// on a parent feature, the Chow-Liu tree of their pair counts (see
    /// `tan`); load it as `tan:PATH`. It trains on from its state file.
    Tan,
}

#[derive(clap::Args, Clone, Debug)]
struct ModelArgs {
    /// Laplace smoothing.
    #[arg(long, default_value_t = 1.0)]
    alpha: f64,
    /// TAN: weight m of naive Bayes's estimate in each feature's
    /// m-estimate given its parent's value (in games with --tan-games).
    #[arg(long, default_value_t = tan::DEFAULT_M)]
    tan_m: f64,
    /// TAN: m = λ N instead of --tan-m, N the positions counted so far, so
    /// that a parent value's own evidence keeps its weight as the counts
    /// grow.
    #[arg(long)]
    tan_lambda: Option<f64>,
    /// TAN: count the pairs in games (each game once) and keep only the
    /// significant edges (an experiment; see `tan`).
    #[arg(long)]
    tan_games: bool,
    /// Predict from cached probabilities (faster) instead of raw counts.
    #[arg(long)]
    use_probs: bool,
    /// Logistic regression: AdaGrad's base step size.
    #[arg(long, default_value_t = 0.05)]
    lr_rate: f64,
    /// Mixture of experts: number of experts.
    #[arg(long, default_value_t = 2)]
    moe_experts: usize,
    /// Mixture of experts: the gate's initial weights are uniform in
    /// [-scale, scale], so the experts start on different positions.
    #[arg(long, default_value_t = 0.1)]
    moe_gate_scale: f64,
    /// Mixture of experts: seed of the gate's initial weights.
    #[arg(long, default_value_t = 1)]
    moe_seed: u64,
    /// Mixture of experts: L2 penalty on the gate's weights, which keeps it
    /// from switching sharply between experts.
    #[arg(long, default_value_t = 0.0)]
    moe_gate_l2: f64,
    /// Factorization machine: length of each feature value's interaction
    /// vector (per class).
    #[arg(long, default_value_t = 8)]
    fm_factors: usize,
    /// Factorization machine: the vectors start uniform in [-scale, scale].
    #[arg(long, default_value_t = 0.01)]
    fm_scale: f64,
    /// Factorization machine: seed of the vectors' starting values.
    #[arg(long, default_value_t = 1)]
    fm_seed: u64,
    /// A model started from a saved one (--init): divide its counts (CNBP)
    /// or AdaGrad sums (LR, every expert of a mixture) by this, so it adapts
    /// faster.
    #[arg(long, default_value_t = 1.0)]
    init_forget: f64,
    /// BDT, BDD and Hoeffding tree: the leaves' classifier.
    #[arg(long, value_enum, default_value_t = NodeKind::Cnbp)]
    leaf: NodeKind,
    /// BDT and BDD: the delegators' routers' classifier.
    #[arg(long, value_enum, default_value_t = NodeKind::Cnbp)]
    router: NodeKind,
    /// BDT: children per split.
    #[arg(long, default_value_t = 2)]
    branch_factor: usize,
    /// BDT: examples a leaf sees between split checks.
    #[arg(long, default_value_t = 2000)]
    split_threshold: u32,
    /// BDT: maximum number of splits (BDD: of leaves and delegators).
    #[arg(long, default_value_t = 20)]
    split_limit: u32,
    /// BDT: divisor applied to a splitting leaf's counts.
    #[arg(long, default_value_t = 10.0)]
    forget_factor: f64,
    /// BDT: error measure for the split check and the routers' targets.
    #[arg(long, value_enum, default_value_t = ErrorMeasure::Abs)]
    error: ErrorMeasure,
    /// BDT: split only if a window's mean error rose by more than this many
    /// standard errors over the previous window's.
    #[arg(long, default_value_t = 0.0)]
    split_z: f64,
    /// BDT: when a leaf splits. (BDD delegators always use their own rule,
    /// see `--model bdd`.)
    #[arg(long, value_enum, default_value_t = SplitRule::Worse)]
    split_rule: SplitRule,
    /// BDT and BDD: what the routers learn to predict.
    #[arg(long, value_enum, default_value_t = RouteTarget::Error)]
    route: RouteTarget,
    /// BDT and BDD: what error routers learn from an example: the best
    /// child's index, or every child's share of the probability the children
    /// gave the outcome (soft: needs --error, and --trial-error with
    /// --route-switch, to be log or winner).
    #[arg(long, value_enum, default_value_t = ErrorTarget::Best)]
    error_target: ErrorTarget,
    /// BDT and BDD with CNBP leaves: every leaf also trains on the examples
    /// routed to the other leaves, weighted by this (0: only its own).
    #[arg(long, default_value_t = 0.0)]
    leaf_share: f64,
    /// BDT and BDD: test each split on the next --split-threshold examples
    /// through it against the node without the split, and undo the split
    /// unless its mean error is lower by this many standard errors.
    #[arg(long)]
    split_trial: Option<f64>,
    /// BDT and BDD: the error split trials compare, and error routers judge
    /// children by (winner: what log-odds play uses).
    #[arg(long, value_enum, default_value_t = ErrorMeasure::Winner)]
    trial_error: ErrorMeasure,
    /// BDT and BDD with cluster routing: train an error router beside each
    /// router, and switch a delegator to error routing when its picks beat
    /// the cluster router's by this many standard errors over a window of
    /// --split-threshold examples (inf: compare and log only).
    #[arg(long)]
    route_switch: Option<f64>,
    /// BDT and BDD with --route-switch: the error routers' classifier
    /// (default: --router's).
    #[arg(long, value_enum)]
    error_router: Option<NodeKind>,
    /// BDT: revisable structure. Every delegator keeps a shadow, the leaf it
    /// was before it split, trained since on every example through it. After
    /// every --split-threshold examples through the delegator, its branch is
    /// merged back into the shadow (as a leaf, which may split again) if the
    /// branch's mean gain over the shadow by --trial-error, less
    /// --seam-weight times its seams, is below minus this many standard
    /// errors (inf: compare and log only). Seams are measured on self-play's
    /// games.
    #[arg(long)]
    revise: Option<f64>,
    /// BDT with --revise: the weight of a branch's seams per position through
    /// its delegator, a seam being the difference in white's log-odds (nats)
    /// of a position between the leaf it is in and the leaf of the position
    /// before it, for moves between two of the branch's leaves.
    #[arg(long, default_value_t = 0.0)]
    seam_weight: f64,
    /// BDT: reset a leaf to a copy of its delegator's shadow (see --revise)
    /// when, over --split-threshold examples routed to it, its mean gain over
    /// the shadow by --trial-error is below minus this many standard errors
    /// (inf: compare and log only).
    #[arg(long)]
    reset_leaves: Option<f64>,
    /// Hoeffding tree: a split is wrong with probability at most this.
    #[arg(long, default_value_t = HtParams::default().delta)]
    ht_delta: f64,
    /// Hoeffding tree: split on the best test once the Hoeffding bound
    /// (bits) is below this, however close the runner-up.
    #[arg(long, default_value_t = HtParams::default().tie)]
    ht_tie: f64,
    /// Hoeffding tree: positions a leaf sees between split checks.
    #[arg(long, default_value_t = HtParams::default().grace)]
    ht_grace: f64,
    /// Hoeffding tree: positions the bound counts as one independent sample
    /// (the positions of a game share its result).
    #[arg(long, default_value_t = HtParams::default().positions_per_sample)]
    ht_positions_per_sample: f64,
    /// Hoeffding tree: most leaves (default: no limit).
    #[arg(long)]
    ht_max_leaves: Option<usize>,
    /// Hoeffding tree: split on a tie only if the best test's gain is above
    /// the bound too (beats not splitting with confidence 1 - delta).
    #[arg(long)]
    ht_pre_prune: bool,
    /// Hoeffding tree: how a leaf chooses its test and decides to split:
    /// information gain about the result by the Hoeffding bound, or (with
    /// --leaf lr) the gain of refitting the leaf's weights on each side of
    /// the test, chosen on half of the games and checked on the other half.
    #[arg(long, value_enum, default_value_t = Criterion::InfoGain)]
    ht_criterion: Criterion,
    /// Hoeffding tree, model gain: split when the best test gains more than
    /// this many nats per position on the held-out half of the games.
    #[arg(long, default_value_t = HtParams::default().gain_threshold)]
    ht_gain_threshold: f64,
    /// Hoeffding tree, model gain: the L2 penalty of the Newton steps that
    /// estimate the gain (a position adds p(1 - p) per class to a weight's
    /// second derivative).
    #[arg(long, default_value_t = HtParams::default().lambda)]
    ht_lambda: f64,
    /// Hoeffding tree, model gain: the fraction of games whose positions the
    /// split statistics keep, chosen by a hash of the game.
    #[arg(long, default_value_t = HtParams::default().sample)]
    ht_sample: f64,
}

impl ModelArgs {
    fn tan_options(&self) -> TanOptions {
        TanOptions { m: self.tan_lambda.unwrap_or(self.tan_m), relative: self.tan_lambda.is_some(), games: self.tan_games }
    }

    /// A new factorization machine with these options.
    fn fresh_fm(&self) -> Fm {
        Fm::new(3, &CATEGORIES, self.fm_factors, self.lr_rate, self.fm_scale, self.fm_seed)
    }

    /// A new Hoeffding tree of one leaf, `root`, with these options.
    fn ht(&self, root: NodeModel) -> Result<Ht> {
        if self.ht_criterion == Criterion::ModelGain && !matches!(root, NodeModel::Lr(_)) {
            bail!("--ht-criterion model-gain needs --leaf lr");
        }
        Ok(Ht::new(root, &CATEGORIES, self.ht_params()))
    }

    fn ht_params(&self) -> HtParams {
        HtParams {
            delta: self.ht_delta,
            tie: self.ht_tie,
            grace: self.ht_grace,
            positions_per_sample: self.ht_positions_per_sample,
            max_leaves: self.ht_max_leaves.unwrap_or(usize::MAX),
            pre_prune: self.ht_pre_prune,
            criterion: self.ht_criterion,
            gain_threshold: self.ht_gain_threshold,
            lambda: self.ht_lambda,
            sample: self.ht_sample,
        }
    }

    fn delegation_params(&self) -> DelegationParams {
        DelegationParams {
            class_num: 3,
            branch_factor: self.branch_factor,
            split_threshold: self.split_threshold,
            split_limit: self.split_limit,
            forget_factor: self.forget_factor,
            nb_alpha: self.alpha,
            use_probs: self.use_probs,
            leaf: self.leaf,
            router: self.router,
            lr_rate: self.lr_rate,
            error: self.error,
            split_z: self.split_z,
            split_rule: self.split_rule,
            route: self.route,
            error_target: self.error_target,
            leaf_share: self.leaf_share,
            split_trial: self.split_trial,
            trial_error: self.trial_error,
            route_switch: self.route_switch,
            error_router: self.error_router.unwrap_or(self.router),
            revise: self.revise,
            seam_weight: self.seam_weight,
            reset_leaves: self.reset_leaves,
        }
    }
}

fn random_seed() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos() as u64
}

/// A player's model, loaded from a `cnbp:PATH`, `bdt:PATH`, `bdd:PATH` or `rand` spec.
enum LoadedModel {
    Cnbp(Cnbp),
    Lr(Logreg),
    Moe(Moe),
    Fm(Fm),
    Ht(Ht),
    Tan(Tan),
    Bdt(Bdt),
    Bdd(Bdd),
    HashMix(HashMix),
    Calibrated(Calibrated),
    Uniform(Uniform),
}

/// A model whose log-probabilities are recalibrated (see `Calibration`),
/// fitted on the positions of a round directory labelled by their games'
/// results. Loaded as `cal:GAMES:SPEC`, one calibration for the whole model,
/// or `leafcal:GAMES:SPEC`, one per leaf of a tree fitted on the positions
/// that leaf predicts, so that the leaves' log-odds mean the same; or
/// `blend:TAU:GAMES:SPEC`, which blends all the leaves' calibrated logits
/// with the weights of `Graph::leaf_weights` at TAU (each leaf calibrated on
/// all positions, weighted the same way), so the prediction changes smoothly
/// across the routers' boundaries.
struct Calibrated {
    model: Box<LoadedModel>,
    per_leaf: bool,
    blend: Option<f64>,
    /// Each leaf's calibration, by node index; `None` for leaves with too
    /// few decisive positions to fit one, which use `whole`.
    leaves: Vec<Option<Calibration>>,
    whole: Calibration,
}

impl Calibrated {
    /// Fewest decisive positions a leaf needs for its own calibration.
    const MIN_DECISIVE: f64 = 200.0;

    fn fit(model: LoadedModel, games: &Path, per_leaf: bool, blend: Option<f64>) -> Result<Self> {
        let data = games::read_labelled(games).with_context(|| format!("reading {games:?}"))?;
        let mut all = Vec::with_capacity(data.len());
        // Each leaf's (log-probabilities, class) pairs and their weights.
        let mut by_leaf = Vec::<(Vec<([f64; 3], usize)>, Vec<f64>)>::new();
        let mut weights = Vec::new();
        for (pos, label) in &data {
            let mut logs = [0.0; 3];
            model.classifier().predict_log(pos, &mut logs);
            let class = label.iter().position(|&x| x == 1.0).context("labels must be one-hot")?;
            match blend {
                Some(tau) => model.leaf_weights(pos, tau, &mut weights),
                None if per_leaf => {
                    weights.clear();
                    weights.push((model.leaf(pos), 1.0));
                }
                None => weights.clear(),
            }
            for &(leaf, weight) in &weights {
                if by_leaf.len() <= leaf {
                    by_leaf.resize(leaf + 1, Default::default());
                }
                let mut leaf_logs = [0.0; 3];
                model.leaf_predict_log(leaf, pos, &mut leaf_logs);
                by_leaf[leaf].0.push((leaf_logs, class));
                by_leaf[leaf].1.push(weight);
            }
            all.push((logs, class));
        }
        let whole = Calibration::fit(&all);
        println!("calibration on {}: {whole} ({} positions)", games.display(), all.len());
        let leaves = by_leaf
            .iter()
            .enumerate()
            .map(|(leaf, (d, w))| {
                if d.is_empty() {
                    return None;
                }
                let total: f64 = w.iter().sum();
                let decisive: f64 = d.iter().zip(w).filter(|((_, c), _)| *c < 2).map(|(_, w)| w).sum();
                let cal = (decisive >= Self::MIN_DECISIVE).then(|| Calibration::fit_weighted(d, w));
                let shown = cal.map_or("the whole model's".to_string(), |c| c.to_string());
                let share = 100.0 * decisive / total;
                println!("  leaf {leaf}: {total:.0} positions, {share:.1}% decisive, calibration {shown}");
                cal
            })
            .collect();
        Ok(Calibrated { model: Box::new(model), per_leaf, blend, leaves, whole })
    }

    /// A leaf's calibration, or the whole model's if the leaf has none.
    fn leaf_calibration(&self, leaf: usize) -> Calibration {
        self.leaves.get(leaf).copied().flatten().unwrap_or(self.whole)
    }

    /// The calibrated logits of the 3 classes.
    fn logits(&self, data: &[u8]) -> [f64; 3] {
        let Some(tau) = self.blend else {
            let mut logs = [0.0; 3];
            self.model.classifier().predict_log(data, &mut logs);
            return self.calibration(data).logits(&logs);
        };
        let mut weights = Vec::with_capacity(16);
        self.model.leaf_weights(data, tau, &mut weights);
        let total: f64 = weights.iter().map(|(_, w)| w).sum();
        let mut z = [0.0; 3];
        for &(leaf, weight) in &weights {
            let mut logs = [0.0; 3];
            self.model.leaf_predict_log(leaf, data, &mut logs);
            let leaf_z = self.leaf_calibration(leaf).logits(&logs);
            (0..3).for_each(|k| z[k] += weight / total * leaf_z[k]);
        }
        z
    }

    fn calibration(&self, data: &[u8]) -> Calibration {
        if !self.per_leaf {
            return self.whole;
        }
        self.leaf_calibration(self.model.leaf(data))
    }
}

impl Classifier for Calibrated {
    fn train(&mut self, _data: &[u8], _label: &[f64]) {
        unimplemented!("calibrated models are only for playing and scoring")
    }
    fn refresh(&mut self) {}
    fn predict(&self, data: &[u8], out: &mut [f64]) {
        let z = self.logits(data);
        let max = z.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let e = z.map(|v| (v - max).exp());
        let sum: f64 = e.iter().sum();
        out[..3].copy_from_slice(&e.map(|v| v / sum));
    }
    fn predict_log(&self, data: &[u8], out: &mut [f64]) {
        out[..3].copy_from_slice(&self.logits(data));
    }
    fn save(&self, _path: &Path) -> std::io::Result<()> {
        Ok(())
    }
}

/// CNBPs that each predict the positions a fixed hash of the position
/// assigns to them: a random split of the work, as a baseline for the
/// delegation models. Loaded as `hashmix:PATH,PATH,...`.
struct HashMix(Vec<Cnbp>);

impl HashMix {
    /// The model that predicts `data`, by an FNV-1a hash of it.
    fn pick(&self, data: &[u8]) -> usize {
        let hash = data.iter().fold(0xcbf2_9ce4_8422_2325u64, |h, &b| (h ^ b as u64).wrapping_mul(0x0100_0000_01b3));
        (hash % self.0.len() as u64) as usize
    }
}

impl Classifier for HashMix {
    fn train(&mut self, _data: &[u8], _label: &[f64]) {
        unimplemented!("hashmix models are only for playing")
    }
    fn refresh(&mut self) {}
    fn predict(&self, data: &[u8], out: &mut [f64]) {
        self.0[self.pick(data)].predict(data, out)
    }
    fn predict_log(&self, data: &[u8], out: &mut [f64]) {
        self.0[self.pick(data)].predict_log(data, out)
    }
    fn save(&self, _path: &Path) -> std::io::Result<()> {
        Ok(())
    }
}

impl LoadedModel {
    fn load(spec: &str, use_probs: bool) -> Result<Self> {
        if spec == "rand" {
            return Ok(LoadedModel::Uniform(Uniform));
        }
        let (kind, path) = spec.split_once(':').with_context(|| format!("expected KIND:PATH or rand, got {spec}"))?;
        let path = Path::new(path);
        Ok(match kind {
            "cnbp" => LoadedModel::Cnbp(Cnbp::load(path, use_probs).with_context(|| format!("loading {path:?}"))?),
            "lr" => LoadedModel::Lr(Logreg::load(path).with_context(|| format!("loading {path:?}"))?),
            "moe" => LoadedModel::Moe(Moe::load(path).with_context(|| format!("loading {path:?}"))?),
            "fm" => LoadedModel::Fm(Fm::load(path).with_context(|| format!("loading {path:?}"))?),
            "ht" => LoadedModel::Ht(Ht::load(path, use_probs).with_context(|| format!("loading {path:?}"))?),
            "tan" => LoadedModel::Tan(Tan::load(path, use_probs).with_context(|| format!("loading {path:?}"))?),
            "bdt" => LoadedModel::Bdt(Bdt::load(path, use_probs).with_context(|| format!("loading {path:?}"))?),
            "bdd" => LoadedModel::Bdd(Bdd::load(path, use_probs).with_context(|| format!("loading {path:?}"))?),
            "hashmix" => LoadedModel::HashMix(HashMix(
                spec[kind.len() + 1..]
                    .split(',')
                    .map(|p| Cnbp::load(Path::new(p), use_probs).with_context(|| format!("loading {p:?}")))
                    .collect::<Result<_>>()?,
            )),
            "cal" | "leafcal" => {
                let (games, inner) = spec[kind.len() + 1..]
                    .split_once(':')
                    .with_context(|| format!("expected {kind}:GAMES:KIND:PATH, got {spec}"))?;
                let inner = LoadedModel::load(inner, use_probs)?;
                LoadedModel::Calibrated(Calibrated::fit(inner, Path::new(games), kind == "leafcal", None)?)
            }
            "blend" => {
                let mut parts = spec[kind.len() + 1..].splitn(3, ':');
                let (Some(tau), Some(games), Some(inner)) = (parts.next(), parts.next(), parts.next()) else {
                    bail!("expected blend:TAU:GAMES:KIND:PATH, got {spec}");
                };
                let tau: f64 = tau.parse().with_context(|| format!("blend TAU {tau:?}"))?;
                let inner = LoadedModel::load(inner, use_probs)?;
                LoadedModel::Calibrated(Calibrated::fit(inner, Path::new(games), true, Some(tau))?)
            }
            _ => bail!("unknown model kind {kind:?}, expected cnbp, lr, moe, fm, ht, tan, bdt, bdd, cal, leafcal or blend"),
        })
    }

    /// Index of the leaf that predicts the position: the tree's leaf, or 0
    /// for models that are not trees.
    fn leaf(&self, data: &[u8]) -> usize {
        match self {
            LoadedModel::Bdt(m) => m.leaf(data),
            LoadedModel::Bdd(m) => m.leaf(data),
            LoadedModel::Ht(m) => m.leaf(data),
            _ => 0,
        }
    }

    /// Each leaf's weight in a blend (`Graph::leaf_weights`, dropping
    /// paths below 0.001); the whole model, as leaf 0, if not a tree.
    fn leaf_weights(&self, data: &[u8], tau: f64, out: &mut Vec<(usize, f64)>) {
        match self {
            LoadedModel::Bdt(m) => m.leaf_weights(data, tau, 1e-3, out),
            LoadedModel::Bdd(m) => m.leaf_weights(data, tau, 1e-3, out),
            // Its tests are hard: all weight on the position's leaf.
            LoadedModel::Ht(m) => {
                out.clear();
                out.push((m.leaf(data), 1.0));
            }
            _ => {
                out.clear();
                out.push((0, 1.0));
            }
        }
    }

    /// The log-probabilities of leaf `leaf` (see `leaf`).
    fn leaf_predict_log(&self, leaf: usize, data: &[u8], out: &mut [f64]) {
        match self {
            LoadedModel::Bdt(m) => m.node_predict_log(leaf, data, out),
            LoadedModel::Bdd(m) => m.node_predict_log(leaf, data, out),
            LoadedModel::Ht(m) => m.node_predict_log(leaf, data, out),
            _ => self.classifier().predict_log(data, out),
        }
    }

    fn classifier(&self) -> &(dyn Classifier + Sync) {
        match self {
            LoadedModel::Cnbp(m) => m,
            LoadedModel::Lr(m) => m,
            LoadedModel::Moe(m) => m,
            LoadedModel::Fm(m) => m,
            LoadedModel::Ht(m) => m,
            LoadedModel::Tan(m) => m,
            LoadedModel::Bdt(m) => m,
            LoadedModel::Bdd(m) => m,
            LoadedModel::HashMix(m) => m,
            LoadedModel::Calibrated(m) => m,
            LoadedModel::Uniform(m) => m,
        }
    }

    /// The model's player at a search depth. Without search, a random model
    /// (`rand`) chooses moves at random whatever the policy. With search it
    /// plays like any other model, valuing every position the same unless
    /// the game is over: at depth 1 it takes a mate in one, at depth 2 it
    /// also avoids allowing one.
    fn player(&self, policy: Policy, temperature: f64, depth: u32) -> Player<'_> {
        let random = matches!(self, LoadedModel::Uniform(_)) && depth == 0;
        let mut player = Player::new(self.classifier(), if random { Policy::Rand } else { policy }, temperature);
        player.depth = depth;
        player
    }
}

fn arena(
    a: &str,
    b: &str,
    games: usize,
    (a_policy, b_policy): (Policy, Policy),
    temperature: f64,
    use_probs: bool,
    seed: u64,
    out: Option<PathBuf>,
    (a_depth, b_depth): (u32, u32),
    (a_value, b_value): (Value, Value),
    (a_calibration, b_calibration): (Option<String>, Option<String>),
) -> Result<()> {
    let (model_a, model_b) = (LoadedModel::load(a, use_probs)?, LoadedModel::load(b, use_probs)?);
    let (mut player_a, mut player_b) =
        (model_a.player(a_policy, temperature, a_depth), model_b.player(b_policy, temperature, b_depth));
    for (player, depth, value, calibration) in
        [(&mut player_a, a_depth, a_value, a_calibration), (&mut player_b, b_depth, b_value, b_calibration)]
    {
        player.depth = depth;
        player.value = value;
        if let Some(c) = calibration {
            player.calibration = Calibration::parse(&c)?;
        }
        check_depth(player)?;
    }
    let depth = |p: &Player| {
        let mut s = String::new();
        if p.depth > 0 {
            s += &format!(", depth {}", p.depth);
        }
        if p.value != Value::LogOdds {
            s += &format!(", value {:?}, calibration {}", p.value, p.calibration);
        }
        s
    };
    println!(
        "arena: A = {a} ({:?}{}), B = {b} ({:?}{}), {games} games, seed {seed}",
        player_a.policy,
        depth(&player_a),
        player_b.policy,
        depth(&player_b)
    );

    let start = Instant::now();
    let records = selfplay::play_match(player_a, player_b, games, seed);
    let secs = start.elapsed().as_secs_f64();
    if let Some(out) = out {
        selfplay::write_round(&out, &records)?;
    }
    if let Some(warning) = selfplay::duplicate_warning(&records) {
        println!("{warning}");
    }

    let m = selfplay::score_match(&records);
    println!("A: +{} -{} ={}, score {:.1}% ({secs:.1}s)", m.wins, m.losses, m.draws, 100.0 * m.score);
    println!("Elo difference A - B: {:+.0} (95% range {:+.0} to {:+.0})", m.elo, m.elo_low, m.elo_high);
    Ok(())
}

/// See `Command::Tournament`. Each distinct SPEC is loaded once.
fn tournament(
    players: &Path,
    out: &Path,
    policy: Policy,
    temperature: f64,
    use_probs: bool,
    anchor: Option<String>,
    retired: Option<&Path>,
    mut opts: tournament::Options,
) -> Result<()> {
    let text = std::fs::read_to_string(players).with_context(|| format!("reading {players:?}"))?;
    let mut specs: Vec<&str> = Vec::new();
    let mut entries = Vec::new();
    for line in text.lines().map(str::trim).filter(|l| !l.is_empty() && !l.starts_with('#')) {
        let fields: Vec<&str> = line.split_whitespace().collect();
        let [name, depth, spec] = fields[..] else { bail!("expected NAME DEPTH SPEC, got {line:?}") };
        let depth: u32 = depth.parse().with_context(|| format!("depth in {line:?}"))?;
        if entries.iter().any(|&(n, _, _)| n == name) {
            bail!("player {name} is listed twice");
        }
        let model = match specs.iter().position(|&s| s == spec) {
            Some(m) => m,
            None => {
                specs.push(spec);
                specs.len() - 1
            }
        };
        entries.push((name, depth, model));
    }
    if entries.len() < 2 {
        bail!("a tournament needs at least two players");
    }
    let mut retired_names: Vec<String> = Vec::new();
    if let Some(path) = retired {
        let text = std::fs::read_to_string(path).with_context(|| format!("reading {path:?}"))?;
        for line in text.lines().map(str::trim).filter(|l| !l.is_empty() && !l.starts_with('#')) {
            let fields: Vec<&str> = line.split_whitespace().collect();
            let [name, depth, _] = fields[..] else { bail!("{path:?}: expected NAME DEPTH SPEC, got {line:?}") };
            depth.parse::<u32>().with_context(|| format!("depth in {line:?}"))?;
            if entries.iter().any(|&(n, _, _)| n == name) || retired_names.iter().any(|n| n == name) {
                bail!("player {name} is listed twice (or both listed and retired)");
            }
            retired_names.push(name.to_string());
        }
    }
    let models = specs.iter().map(|s| LoadedModel::load(s, use_probs)).collect::<Result<Vec<_>>>()?;
    let mut entrants = Vec::new();
    for &(name, depth, model) in &entries {
        let player = models[model].player(policy, temperature, depth);
        check_depth(&player)?;
        entrants.push(tournament::Entrant { name: name.to_string(), player });
    }
    if let Some(anchor) = anchor {
        opts.anchor =
            Some(entries.iter().position(|&(n, _, _)| n == anchor).with_context(|| format!("no player {anchor}"))?);
    }
    std::fs::create_dir_all(out)?;
    std::fs::write(out.join("players.txt"), &text)?;
    let n = entrants.len();
    let also = if retired_names.is_empty() { String::new() } else { format!(" ({} retired)", retired_names.len()) };
    println!("tournament: {n} players{also}, {} games per tournament, seed {}", n * (n - 1), opts.seed);
    tournament::run(&entrants, &retired_names, out, &opts)?;
    Ok(())
}

/// Search values moves in log-odds, which the log-odds policies use, or by
/// the outcome at the end of their principal variation, which the
/// expected-score ones use.
fn check_depth(player: &Player) -> Result<()> {
    let searchable = matches!(
        player.policy,
        Policy::LogOdds
            | Policy::LogOddsSoftmax
            | Policy::WldScore
            | Policy::WldScoreJitter10
            | Policy::WldScoreJitter20
            | Policy::Rand
    );
    if player.depth > 0 && !searchable {
        bail!("search (depth > 0) needs a log-odds or expected-score policy, not {:?}", player.policy);
    }
    if player.depth == 0 && player.value != Value::LogOdds {
        bail!("the {:?} value is only used by search (depth > 0)", player.value);
    }
    Ok(())
}

fn main() -> Result<()> {
    match Cli::parse().command {
        Command::Arena {
            a,
            b,
            games,
            a_policy,
            b_policy,
            temperature,
            use_probs,
            seed,
            out,
            a_depth,
            b_depth,
            a_value,
            b_value,
            a_calibration,
            b_calibration,
        } => {
            arena(
                &a,
                &b,
                games,
                (a_policy, b_policy),
                temperature,
                use_probs,
                seed.unwrap_or_else(random_seed),
                out,
                (a_depth, b_depth),
                (a_value, b_value),
                (a_calibration, b_calibration),
            )
        }
        Command::Tournament {
            players,
            out,
            tournaments,
            policy,
            temperature,
            use_probs,
            seed,
            k,
            prior_draws,
            anchor,
            no_catch_up,
            retired,
            save_games,
        } => tournament(
            &players,
            &out,
            policy,
            temperature,
            use_probs,
            anchor,
            retired.as_deref(),
            tournament::Options { tournaments, seed, k, prior_draws, anchor: None, catch_up: !no_catch_up, save_games },
        ),
        Command::SelfPlay {
            out,
            model,
            rounds,
            games,
            policy,
            temperature,
            seed,
            threads,
            vs_previous,
            no_games,
            depth,
            label_depth,
            label_result,
            label_model,
            round_forget,
            age_forget,
            resume,
            keep_states,
            init,
            params,
        } => {
            if keep_states == 1 {
                bail!("--keep-states 1 would delete the state of the version before the last, which --resume needs");
            }
            if let Some(threads) = threads {
                rayon::ThreadPoolBuilder::new().num_threads(threads).build_global()?;
            }
            let seed = seed.unwrap_or_else(random_seed);
            check_depth(&Player { depth, ..Player::new(&Uniform, policy, temperature) })?;
            let run = SelfPlayRun {
                out,
                rounds,
                games,
                policy,
                temperature,
                seed,
                vs_previous,
                no_games,
                depth,
                label_depth,
                label_result,
                label_model: label_model.map(|spec| LoadedModel::load(&spec, params.use_probs)).transpose()?,
                round_forget,
                age_forget,
                keep_states,
            };
            let fresh = || Cnbp::new(3, &CATEGORIES, params.alpha, params.use_probs);
            let initial = || -> Result<Cnbp> {
                match &init {
                    Some(path) => {
                        let mut cnbp =
                            Cnbp::load(path, params.use_probs).with_context(|| format!("loading {path:?}"))?;
                        cnbp.forget(params.init_forget);
                        Ok(cnbp)
                    }
                    None => Ok(fresh()),
                }
            };
            // A tree's root leaf: --init's model, of the --leaf kind.
            let tree_root = || -> Result<NodeModel> {
                Ok(match (params.leaf, &init) {
                    (NodeKind::Cnbp, _) => NodeModel::Cnbp(initial()?),
                    (NodeKind::Lr, Some(path)) => {
                        let mut lr = Logreg::load(path).with_context(|| format!("loading {path:?}"))?;
                        lr.forget(params.init_forget);
                        NodeModel::Lr(lr)
                    }
                    (NodeKind::Lr, None) => NodeModel::Lr(Logreg::new(3, &CATEGORIES, params.lr_rate)),
                })
            };
            match model {
                ModelKind::Cnbp if resume => {
                    // Round N plays version N against N-1 and then saves
                    // version N+1, so the last saved version is the next round.
                    let saved = |n: u64| run.out.join(format!("cnbp{n}.model"));
                    let start = (1..).take_while(|&n| saved(n).exists()).last().context("no saved models to resume")?;
                    let load = |n: u64| if n == 0 { Ok(fresh()) } else { Cnbp::load(&saved(n), params.use_probs) };
                    run.run("cnbp", load(start)?, load(start - 1)?, start)
                }
                ModelKind::Cnbp => run.run("cnbp", initial()?, initial()?, 0),
                ModelKind::Lr if resume => {
                    let saved = |n: u64| run.out.join(format!("lr{n}.model"));
                    let start = (1..).take_while(|&n| saved(n).exists()).last().context("no saved models to resume")?;
                    let fresh = || Logreg::new(3, &CATEGORIES, params.lr_rate);
                    let load = |n: u64| if n == 0 { Ok(fresh()) } else { Logreg::load(&saved(n)) };
                    run.run("lr", load(start)?, load(start - 1)?, start)
                }
                ModelKind::Moe if resume => {
                    let saved = |n: u64| run.out.join(format!("moe{n}.model"));
                    let start = (1..).take_while(|&n| saved(n).exists()).last().context("no saved models to resume")?;
                    if start == 1 {
                        bail!("resume a mixture from round 2 on");
                    }
                    run.run("moe", Moe::load(&saved(start))?, Moe::load(&saved(start - 1))?, start)
                }
                ModelKind::Fm if resume => {
                    let saved = |n: u64| run.out.join(format!("fm{n}.model"));
                    let start = (1..).take_while(|&n| saved(n).exists()).last().context("no saved models to resume")?;
                    let fresh = || params.fresh_fm();
                    let load = |n: u64| if n == 0 { Ok(fresh()) } else { Fm::load(&saved(n)) };
                    run.run("fm", load(start)?, load(start - 1)?, start)
                }
                // TAN's model files lack its pair counts: it resumes from its
                // state files, like the trees.
                ModelKind::Tan if resume => {
                    let saved = |n: u64| run.out.join(format!("tan{n}.model"));
                    let start = (1..).take_while(|&n| saved(n).exists()).last().context("no saved models to resume")?;
                    let load = |n: u64| -> Result<Tan> {
                        let path = run.out.join(format!("tan{n}.state"));
                        if !path.exists() {
                            bail!("{path:?} is missing: a TAN resumes from the states of its last two versions");
                        }
                        Tan::load_state(&path, params.alpha, params.tan_options(), params.use_probs)
                            .with_context(|| format!("loading the state of tan{n}"))
                    };
                    run.run("tan", load(start)?, load(start - 1)?, start)
                }
                ModelKind::Tan => {
                    if init.is_some() {
                        bail!("a TAN starts from scratch (no --init)");
                    }
                    let model = Tan::new(3, &CATEGORIES, params.alpha, params.tan_options(), params.use_probs);
                    run.run("tan", model.clone(), model, 0)
                }
                // Trees resume from their state files, which the model files
                // lack (see `state`); version 0's is saved at the start.
                ModelKind::Bdt | ModelKind::Bdd | ModelKind::Ht if resume => {
                    let name = format!("{model:?}").to_lowercase();
                    let saved = |n: u64| run.out.join(format!("{name}{n}.model"));
                    let start = (1..).take_while(|&n| saved(n).exists()).last().context("no saved models to resume")?;
                    let state = |n: u64| -> Result<PathBuf> {
                        let path = run.out.join(format!("{name}{n}.state"));
                        if !path.exists() {
                            bail!("{path:?} is missing: a tree resumes from the states of its last two versions");
                        }
                        Ok(path)
                    };
                    let context = |n: u64| format!("loading the state of {name}{n}");
                    match model {
                        ModelKind::Bdt => {
                            let load = |n: u64| -> Result<Bdt> {
                                Bdt::load_state(&state(n)?, &CATEGORIES, params.delegation_params())
                                    .with_context(|| context(n))
                            };
                            run.run("bdt", load(start)?, load(start - 1)?, start)
                        }
                        ModelKind::Bdd => {
                            let load = |n: u64| -> Result<Bdd> {
                                Bdd::load_state(&state(n)?, &CATEGORIES, params.delegation_params())
                                    .with_context(|| context(n))
                            };
                            run.run("bdd", load(start)?, load(start - 1)?, start)
                        }
                        _ => {
                            let root = tree_root()?;
                            let load = |n: u64| -> Result<Ht> {
                                Ht::load_state(&state(n)?, &root, &CATEGORIES, params.ht_params())
                                    .with_context(|| context(n))
                            };
                            run.run("ht", load(start)?, load(start - 1)?, start)
                        }
                    }
                }
                ModelKind::Fm => {
                    if init.is_some() {
                        bail!("a factorization machine starts from scratch (no --init)");
                    }
                    let model = params.fresh_fm();
                    run.run("fm", model.clone(), model, 0)
                }
                ModelKind::Ht => {
                    let model = params.ht(tree_root()?)?;
                    run.run("ht", model.clone(), model, 0)
                }
                ModelKind::Bdt => {
                    let model = Bdt::starting_from(tree_root()?, &CATEGORIES, params.delegation_params());
                    run.run("bdt", model.clone(), model, 0)
                }
                ModelKind::Bdd => {
                    let model = Bdd::starting_from(tree_root()?, &CATEGORIES, params.delegation_params());
                    run.run("bdd", model.clone(), model, 0)
                }
                ModelKind::Moe => {
                    let model = match &init {
                        Some(path) => {
                            let expert = Logreg::load(path).with_context(|| format!("loading {path:?}"))?;
                            let mut moe = Moe::from_expert(
                                expert,
                                &CATEGORIES,
                                params.moe_experts,
                                params.lr_rate,
                                params.moe_gate_scale,
                                params.moe_seed,
                            );
                            moe.forget(params.init_forget);
                            moe.with_gate_l2(params.moe_gate_l2)
                        }
                        None => Moe::new(
                            &CATEGORIES,
                            params.moe_experts,
                            params.lr_rate,
                            params.moe_gate_scale,
                            params.moe_seed,
                        )
                        .with_gate_l2(params.moe_gate_l2),
                    };
                    run.run("moe", model.clone(), model, 0)
                }
                ModelKind::Lr => {
                    let model = match &init {
                        Some(path) => {
                            let mut lr = Logreg::load(path).with_context(|| format!("loading {path:?}"))?;
                            lr.forget(params.init_forget);
                            lr
                        }
                        None => Logreg::new(3, &CATEGORIES, params.lr_rate),
                    };
                    run.run("lr", model.clone(), model, 0)
                }
            }
        }
        Command::Train { games, out, model, rounds, seed, start, label_depth, label_result, label_model, params } => {
            if label_depth.is_some() && !matches!(model, ModelKind::Lr) {
                bail!("--label-depth is only implemented for lr");
            }
            if label_model.is_some() && label_depth.is_none() {
                bail!("--label-model needs --label-depth");
            }
            let label_model = label_model.map(|spec| LoadedModel::load(&spec, params.use_probs)).transpose()?;
            // A flat model's --start: its model file, forgotten by --init-forget.
            fn flat<M: Classifier>(
                start: Option<&Path>,
                forget: f64,
                load: impl FnOnce(&Path) -> std::io::Result<M>,
            ) -> Result<Option<M>> {
                let Some(path) = start else { return Ok(None) };
                let mut model = load(path).with_context(|| format!("loading {path:?}"))?;
                if forget != 1.0 {
                    model.forget(forget);
                }
                Ok(Some(model))
            }
            let (forget, start) = (params.init_forget, start.as_deref());
            let tree_context = || format!("loading the state {:?}", start.unwrap());
            if start.is_some() && forget != 1.0 && matches!(model, ModelKind::Bdt | ModelKind::Bdd | ModelKind::Ht) {
                bail!("--init-forget applies to the --start of cnbp, lr, fm and moe, not of trees");
            }
            match model {
                ModelKind::Cnbp => {
                    let model = flat(start, forget, |p| Cnbp::load(p, params.use_probs))?
                        .unwrap_or_else(|| Cnbp::new(3, &CATEGORIES, params.alpha, params.use_probs));
                    train_rounds(&games, &out, rounds, seed, "cnbp", model)
                }
                ModelKind::Lr => {
                    let model = flat(start, forget, Logreg::load)?
                        .unwrap_or_else(|| Logreg::new(3, &CATEGORIES, params.lr_rate));
                    match label_depth {
                        Some(depth) => {
                            let fixed = label_model.as_ref().map(|m| m.classifier());
                            train_rounds_labelled(&games, &out, rounds, seed, "lr", model, fixed, depth, label_result)
                        }
                        None => train_rounds(&games, &out, rounds, seed, "lr", model),
                    }
                }
                // Its state file: given, or the one beside the given model file.
                ModelKind::Tan => {
                    let model = flat(start, forget, |p| Tan::load_start(p, params.alpha, params.tan_options(), params.use_probs))?
                        .unwrap_or_else(|| Tan::new(3, &CATEGORIES, params.alpha, params.tan_options(), params.use_probs));
                    train_rounds(&games, &out, rounds, seed, "tan", model)
                }
                ModelKind::Fm => {
                    let model = flat(start, forget, Fm::load)?.unwrap_or_else(|| params.fresh_fm());
                    train_rounds(&games, &out, rounds, seed, "fm", model)
                }
                ModelKind::Moe => {
                    let model = flat(start, forget, Moe::load)?.unwrap_or_else(|| {
                        Moe::new(
                            &CATEGORIES,
                            params.moe_experts,
                            params.lr_rate,
                            params.moe_gate_scale,
                            params.moe_seed,
                        )
                        .with_gate_l2(params.moe_gate_l2)
                    });
                    train_rounds(&games, &out, rounds, seed, "moe", model)
                }
                ModelKind::Bdt => {
                    let model = match start {
                        Some(path) => {
                            Bdt::load_state(path, &CATEGORIES, params.delegation_params()).with_context(tree_context)?
                        }
                        None => Bdt::new(&CATEGORIES, params.delegation_params()),
                    };
                    train_rounds(&games, &out, rounds, seed, "bdt", model)
                }
                ModelKind::Bdd => {
                    let model = match start {
                        Some(path) => {
                            Bdd::load_state(path, &CATEGORIES, params.delegation_params()).with_context(tree_context)?
                        }
                        None => Bdd::new(&CATEGORIES, params.delegation_params()),
                    };
                    train_rounds(&games, &out, rounds, seed, "bdd", model)
                }
                ModelKind::Ht => {
                    let root = params.delegation_params().new_classifier(params.leaf, 3, &CATEGORIES);
                    let model = match start {
                        Some(path) => {
                            Ht::load_state(path, &root, &CATEGORIES, params.ht_params()).with_context(tree_context)?
                        }
                        None => params.ht(root)?,
                    };
                    train_rounds(&games, &out, rounds, seed, "ht", model)
                }
            }
        }
        Command::ReplayGames { players, games, out, policy, temperature, use_probs, seed } => {
            replay_games(&players, &games, &out, policy, temperature, use_probs, seed)
        }
        Command::PolicyStats { model, games, policy, temperature, temperatures, use_probs, seed } => {
            policy_stats(&model, games, policy, temperature, &temperatures, use_probs, seed)
        }
        Command::Calibration { model, games, use_probs } => calibration(&model, &games, use_probs),
        Command::Routing { model, games, use_probs } => routing(&model, &games, use_probs),
        Command::Leaves { model, out, use_probs } => {
            let model = LoadedModel::load(&model, use_probs)?;
            let leaves: Vec<_> = match &model {
                LoadedModel::Bdt(m) => m.leaves().collect(),
                LoadedModel::Bdd(m) => m.leaves().collect(),
                LoadedModel::Ht(m) => m.leaves().collect(),
                _ => bail!("only bdt, bdd and ht models have leaves"),
            };
            std::fs::create_dir_all(&out)?;
            for (idx, leaf) in leaves {
                let path = out.join(format!("leaf{idx}.model"));
                leaf.save(&path).with_context(|| format!("writing {path:?}"))?;
                println!("leaf {idx} ({:?}): {}", leaf.kind(), path.display());
            }
            Ok(())
        }
        Command::EvalLoss { model, games, use_probs, fit_calibration, calibration, routed_by, leaf } => {
            let routed = routed_by.as_deref().zip(leaf);
            eval_loss(&model, &games, use_probs, fit_calibration, calibration.as_deref(), routed)
        }
        Command::RankTest { source, models, positions, playouts, playout_policy, seed, use_probs } => {
            rank_test(&source, &models, positions, playouts, playout_policy, seed, use_probs)
        }
        Command::Xcheck { file } => xcheck(file),
        Command::BenchMovegen { games, seed } => bench_movegen(games, seed),
        Command::BenchCnbp { games_dir, model_out, predictions_out, alpha, use_probs, reps } => bench_classifier(
            "cnbp",
            || Cnbp::new(3, &CATEGORIES, alpha, use_probs),
            &games_dir,
            &model_out,
            &predictions_out,
            reps,
        ),
        Command::BenchBdt {
            games_dir,
            model_out,
            predictions_out,
            branch_factor,
            split_threshold,
            split_limit,
            forget_factor,
            alpha,
            use_probs,
            reps,
        } => {
            let params = DelegationParams {
                class_num: 3,
                branch_factor,
                split_threshold,
                split_limit,
                forget_factor,
                nb_alpha: alpha,
                use_probs,
                leaf: NodeKind::Cnbp,
                router: NodeKind::Cnbp,
                lr_rate: 0.05,
                error: ErrorMeasure::Abs,
                split_z: 0.0,
                split_rule: SplitRule::Worse,
                route: RouteTarget::Error,
                error_target: ErrorTarget::Best,
                leaf_share: 0.0,
                split_trial: None,
                trial_error: ErrorMeasure::Winner,
                route_switch: None,
                error_router: NodeKind::Cnbp,
                revise: None,
                seam_weight: 0.0,
                reset_leaves: None,
            };
            bench_classifier(
                "bdt",
                || Bdt::new(&CATEGORIES, params.clone()),
                &games_dir,
                &model_out,
                &predictions_out,
                reps,
            )
        }
    }
}

fn train_rounds<M: Classifier>(games: &Path, out: &Path, rounds: u64, seed: u64, name: &str, mut model: M) -> Result<()> {
    use rand::seq::SliceRandom;
    std::fs::create_dir_all(out)?;
    for round in 0..rounds {
        let dir = games.join(format!("round{round}"));
        let seed = selfplay::derive_seed(seed, round, u64::MAX);
        let start;
        let positions;
        if model.needs_games() {
            // As self-play trains it: the round's games, then their positions
            // shuffled, each with its game's id.
            let round_games = games::read_round_games(&dir).with_context(|| format!("reading {}", dir.display()))?;
            let mut data: Vec<_> = (round_games.iter().enumerate())
                .flat_map(|(g, game)| game.iter().map(move |&(p, l)| (p, l, round << 32 | g as u64)))
                .collect();
            data.shuffle(&mut StdRng::seed_from_u64(seed));
            start = Instant::now();
            let played: Vec<Vec<Encoded>> = round_games.iter().map(|g| g.iter().map(|&(p, _)| p).collect()).collect();
            model.observe_games(&played.iter().map(Vec::as_slice).collect::<Vec<_>>());
            for (pos, label, game) in &data {
                model.train_in_game(pos, label, *game);
            }
            positions = data.len();
        } else {
            let mut data = games::read_round(&dir).with_context(|| format!("reading {}", dir.display()))?;
            data.shuffle(&mut StdRng::seed_from_u64(seed));
            start = Instant::now();
            for (pos, label) in &data {
                model.train(pos, label);
            }
            positions = data.len();
        }
        model.refresh();
        model.save(&out.join(format!("{name}{}.model", round + 1)))?;
        println!("round {round}: {positions} positions, train {:.2}s", start.elapsed().as_secs_f64());
    }
    // A tree's state, to train it further (--start).
    if rounds > 0 {
        model.save_state(&out.join(format!("{name}{rounds}.state")))?;
    }
    Ok(())
}

/// As `train_rounds` for a model that trains on positions, but each
/// position's label is the outcome a `depth`-ply search by the model, as it
/// starts the round (or by `fixed`, as self-play's --label-model), expects
/// from it, mixed with the game's result (`selfplay::search_labels`, as
/// self-play's --label-depth), calibrated on the round's games
/// (`selfplay::fit_calibration`). The positions are the same and trained on
/// in the same order as by `train_rounds`.
#[allow(clippy::too_many_arguments)]
fn train_rounds_labelled<M: Classifier + Sync>(
    games: &Path,
    out: &Path,
    rounds: u64,
    seed: u64,
    name: &str,
    mut model: M,
    fixed: Option<&(dyn Classifier + Sync)>,
    depth: u32,
    result_weight: f64,
) -> Result<()> {
    use rand::seq::SliceRandom;
    std::fs::create_dir_all(out)?;
    println!(
        "labels from depth-{depth} search by {} with result weight {result_weight}",
        if fixed.is_some() { "a fixed model" } else { "the model as it starts each round" }
    );
    for round in 0..rounds {
        let dir = games.join(format!("round{round}"));
        let seed = selfplay::derive_seed(seed, round, u64::MAX);
        let records = read_round_records(&dir).with_context(|| format!("reading {}", dir.display()))?;
        let start = Instant::now();
        let labeller: &(dyn Classifier + Sync) = fixed.unwrap_or(&model);
        let calibration = selfplay::fit_calibration(&records, labeller);
        let labels = selfplay::search_labels(&records, labeller, calibration, depth, result_weight);
        let label_secs = start.elapsed().as_secs_f64();
        let mut data: Vec<(Encoded, [f64; 3])> = (records.iter().zip(&labels))
            .flat_map(|(r, l)| r.positions.iter().copied().zip(l.iter().copied()))
            .collect();
        data.shuffle(&mut StdRng::seed_from_u64(seed));
        let start = Instant::now();
        for (pos, label) in &data {
            model.train(pos, label);
        }
        model.refresh();
        model.save(&out.join(format!("{name}{}.model", round + 1)))?;
        println!(
            "round {round}: {} positions, {} games, calibration {calibration}, labels {label_secs:.2}s, train {:.2}s",
            data.len(),
            records.len(),
            start.elapsed().as_secs_f64()
        );
    }
    if rounds > 0 {
        model.save_state(&out.join(format!("{name}{rounds}.state")))?;
    }
    Ok(())
}

/// The games of a round directory of game directories (links will do), in
/// the order of their names (as `games::read_round`), each rebuilt from its
/// moves (human.games) and checked against its saved positions.
fn read_round_records(dir: &Path) -> Result<Vec<selfplay::GameRecord>> {
    let mut paths = std::fs::read_dir(dir)?.map(|e| Ok(e?.path())).collect::<std::io::Result<Vec<_>>>()?;
    paths.retain(|p| p.join(games::OUTCOME_FILES[0].0).exists());
    paths.sort();
    if paths.is_empty() {
        bail!("{}: no game directories", dir.display());
    }
    paths.iter().map(|p| read_game_record(p).with_context(|| format!("game {}", p.display()))).collect()
}

fn read_game_record(dir: &Path) -> Result<selfplay::GameRecord> {
    use shakmaty::san::SanPlus;
    let saved = games::read_labelled(dir)?;
    let text = std::fs::read_to_string(dir.join("human.games"))?;
    let mut game = Game::default();
    let (mut moves, mut positions) = (Vec::new(), Vec::new());
    for tok in text.split_whitespace() {
        if matches!(tok, "1-0" | "0-1" | "1/2-1/2" | "*") {
            break;
        }
        if tok.ends_with('.') && tok[..tok.len() - 1].bytes().all(|b| b.is_ascii_digit()) {
            continue;
        }
        let san: SanPlus = tok.parse().map_err(|e| anyhow::anyhow!("{tok}: {e}"))?;
        let mv = san.san.to_move(game.position()).map_err(|e| anyhow::anyhow!("{tok}: {e}"))?;
        game.play(mv);
        moves.push(mv);
        positions.push(encoding::encode(game.position()));
    }
    if positions.len() != saved.len() || positions.iter().zip(&saved).any(|(a, (b, _))| a != b) {
        bail!("its moves do not give its saved positions ({} vs {})", positions.len(), saved.len());
    }
    let Some(&(_, label)) = saved.first() else { bail!("no positions") };
    let result = match label {
        [1.0, 0.0, 0.0] => GameResult::WhiteWin,
        [0.0, 1.0, 0.0] => GameResult::BlackWin,
        _ => GameResult::Draw,
    };
    if game.result() != Some(result) && result != GameResult::Draw {
        bail!("its moves do not end in its result");
    }
    Ok(selfplay::GameRecord { result, moves, positions, movetext: text.trim().to_string() })
}

fn replay_games(
    players: &Path,
    games_list: &Path,
    out: &Path,
    policy: Policy,
    temperature: f64,
    use_probs: bool,
    seed: u64,
) -> Result<()> {
    use rayon::prelude::*;
    let text = std::fs::read_to_string(players).with_context(|| format!("reading {players:?}"))?;
    let mut entries: Vec<(&str, u32, &str)> = Vec::new();
    for line in text.lines().map(str::trim).filter(|l| !l.is_empty() && !l.starts_with('#')) {
        let fields: Vec<&str> = line.split_whitespace().collect();
        let [name, depth, spec] = fields[..] else { bail!("expected NAME DEPTH SPEC, got {line:?}") };
        entries.push((name, depth.parse()?, spec));
    }
    let n = entries.len();
    let index = |name: &str| entries.iter().position(|&(e, _, _)| e == name).with_context(|| format!("no player {name}"));
    let list = std::fs::read_to_string(games_list)?;
    let mut games: Vec<(u64, usize, usize)> = Vec::new();
    for line in list.lines().map(str::trim).filter(|l| !l.is_empty()) {
        let f: Vec<&str> = line.split_whitespace().collect();
        let [t, w, b] = f[..] else { bail!("expected T WHITE BLACK, got {line:?}") };
        games.push((t.parse()?, index(w)?, index(b)?));
    }
    // Only the players in these games are loaded; specs shared by entries are loaded once.
    let mut specs: Vec<&str> = Vec::new();
    for &(_, w, b) in &games {
        for i in [w, b] {
            if !specs.contains(&entries[i].2) {
                specs.push(entries[i].2);
            }
        }
    }
    let models = specs.iter().map(|s| LoadedModel::load(s, use_probs)).collect::<Result<Vec<_>>>()?;
    let player = |i: usize| -> Result<Player<'_>> {
        let m = specs.iter().position(|&s| s == entries[i].2).unwrap();
        let p = models[m].player(policy, temperature, entries[i].1);
        check_depth(&p)?;
        Ok(p)
    };
    let mut players_of = vec![None; n];
    for &(_, w, b) in &games {
        for i in [w, b] {
            if players_of[i].is_none() {
                players_of[i] = Some(player(i)?);
            }
        }
    }
    let order = tournament::pairings(n);
    let played = games
        .par_iter()
        .map(|&(t, w, b)| {
            let g = order.iter().position(|&p| p == (w, b)).expect("no such pairing");
            let record = selfplay::play_game(players_of[w].unwrap(), players_of[b].unwrap(), selfplay::derive_seed(seed, t, g as u64));
            let dir = tournament::game_dir(out, t, entries[w].0, entries[b].0);
            selfplay::write_round(&dir, std::slice::from_ref(&record))?;
            Ok((t, w, b, record.result, record.moves.len()))
        })
        .collect::<Result<Vec<_>>>()?;
    for (t, w, b, result, plies) in played {
        let r = match result {
            GameResult::WhiteWin => "1-0",
            GameResult::BlackWin => "0-1",
            GameResult::Draw => "1/2-1/2",
        };
        println!("{t},{},{},{r},{plies}", entries[w].0, entries[b].0);
    }
    Ok(())
}

fn policy_stats(
    model: &str,
    games: usize,
    policy: Policy,
    temperature: f64,
    temperatures: &[f64],
    use_probs: bool,
    seed: u64,
) -> Result<()> {
    let model = LoadedModel::load(model, use_probs)?;
    let player = model.player(policy, temperature, 0);
    let mut rng = StdRng::seed_from_u64(seed);
    let (mut positions, mut jitter_off) = (0usize, 0usize);
    let mut softmax_off = vec![0.0; temperatures.len()];
    let mut gaps = Vec::new();
    let mut draws = Vec::new();
    let mut underflows = 0usize;
    let mut scores = [0.0; 3];
    // Statistics are about log-odds for the log-odds policies, otherwise
    // about expected score.
    let log_odds = matches!(policy, Policy::LogOdds | Policy::LogOddsSoftmax);

    for _ in 0..games {
        let mut game = Game::default();
        while game.result().is_none() {
            let pos = game.position();
            let candidates = player::candidates(pos);
            let (win, loss) = if pos.turn().is_white() { (0, 1) } else { (1, 0) };
            let expected: Vec<f64> = candidates
                .iter()
                .map(|c| {
                    player.model.predict(&c.position, &mut scores);
                    draws.push(scores[2]);
                    if scores[win] == 0.0 || scores[loss] == 0.0 {
                        underflows += 1;
                    }
                    if log_odds {
                        player::log_odds(scores[win], scores[loss])
                    } else {
                        scores[win] + scores[2] / 2.0
                    }
                })
                .collect();

            if expected.len() > 1 {
                let mut sorted = expected.clone();
                sorted.sort_by(|a, b| b.total_cmp(a));
                let (best, second) = (sorted[0], sorted[1]);
                gaps.push(best - second);
                positions += 1;
                // Off-best probability under softmax: 1 - p(top move); moves
                // tied for the top count as the top move.
                for (off, &t) in softmax_off.iter_mut().zip(temperatures) {
                    let weights = expected.iter().map(|v| ((v - best) / t).exp());
                    let total: f64 = weights.clone().sum();
                    let top: f64 = weights.filter(|&w| w == 1.0).sum();
                    *off += 1.0 - top / total;
                }
                let jittered = expected.iter().map(|v| v * (1.0 + rng.random_range(-0.1..=0.1)));
                let pick = jittered.enumerate().max_by(|a, b| a.1.total_cmp(&b.1)).unwrap().0;
                if expected[pick] < best {
                    jitter_off += 1;
                }
            }

            let chosen = player::select(player, pos.turn(), &candidates, &mut rng);
            game.play(candidates[chosen].mv);
        }
    }

    gaps.sort_by(f64::total_cmp);
    let pct = |q: f64| gaps[((gaps.len() - 1) as f64 * q) as usize];
    println!("{positions} positions with 2+ moves, {games} games played with {policy:?}");
    println!(
        "gap between top two moves: median {:.1e}, 25% {:.1e}, 75% {:.1e}, 90% {:.1e}; exact ties {:.1}%",
        pct(0.5),
        pct(0.25),
        pct(0.75),
        pct(0.9),
        100.0 * gaps.iter().filter(|&&g| g == 0.0).count() as f64 / gaps.len() as f64
    );
    draws.sort_by(f64::total_cmp);
    let draw = |q: f64| draws[((draws.len() - 1) as f64 * q) as usize];
    println!(
        "predicted draw probability over all candidate positions: 10% {:.4}, median {:.6}, 90% {:.6}",
        draw(0.1),
        draw(0.5),
        draw(0.9)
    );
    println!(
        "candidate positions with P(win) or P(loss) exactly 0: {:.2}%",
        100.0 * underflows as f64 / draws.len() as f64
    );
    if log_odds {
        println!("(gaps and softmax figures below are in log-odds, nats)");
    }
    println!("jitter10: plays a non-top move {:.1}% of the time", 100.0 * jitter_off as f64 / positions as f64);
    for (off, t) in softmax_off.iter().zip(temperatures) {
        println!("softmax T={t}: plays a non-top move {:.1}% of the time", 100.0 * off / positions as f64);
    }
    Ok(())
}

/// Winner log-loss of white log-odds `v` for a game white won (`y` 1) or lost
/// (`y` -1).
fn winner_loss(v: f64, y: f64) -> f64 {
    let z = y * v;
    if z > 0.0 { (-z).exp().ln_1p() } else { -z + z.exp().ln_1p() }
}

/// See `Command::Routing`.
fn routing(spec: &str, games: &Path, use_probs: bool) -> Result<()> {
    let LoadedModel::Bdt(bdt) = LoadedModel::load(spec, use_probs)? else { bail!("routing needs a bdt: model") };
    let data = games::read_labelled(games)?;
    let raw_odds = |leaf: usize, pos: &[u8]| {
        let mut out = [0.0; 3];
        bdt.node_predict_log(leaf, pos, &mut out);
        out[0] - out[1]
    };
    let decisive: Vec<(&[u8], f64)> = data
        .iter()
        .filter(|(_, label)| label[2] == 0.0)
        .map(|(pos, label)| (&pos[..], if label[0] == 1.0 { 1.0 } else { -1.0 }))
        .collect();
    if decisive.is_empty() {
        bail!("no decisive positions in {games:?}");
    }

    // One scale and offset for the whole tree's log-odds, by Newton's method.
    let tree_odds: Vec<f64> = decisive.iter().map(|(pos, _)| raw_odds(bdt.leaf(pos), pos)).collect();
    let (mut a, mut b) = (1.0, 0.0);
    for _ in 0..50 {
        let (mut ga, mut gb, mut haa, mut hab, mut hbb) = (0.0, 0.0, 0.0, 0.0, 0.0);
        for ((_, y), v) in decisive.iter().zip(&tree_odds) {
            let s = 1.0 / (1.0 + (y * (a * v + b)).exp());
            ga -= s * y * v;
            gb -= s * y;
            let w = s * (1.0 - s);
            haa += w * v * v;
            hab += w * v;
            hbb += w;
        }
        let det = haa * hbb - hab * hab;
        if det.abs() < 1e-300 {
            break;
        }
        let (da, db) = ((hbb * ga - hab * gb) / det, (haa * gb - hab * ga) / det);
        a -= da;
        b -= db;
        if da.abs() + db.abs() < 1e-10 {
            break;
        }
    }
    let odds = |leaf: usize, pos: &[u8]| a * raw_odds(leaf, pos) + b;
    let tree_loss = decisive.iter().zip(&tree_odds).map(|((_, y), v)| winner_loss(a * v + b, *y)).sum::<f64>();
    println!(
        "{} decisive positions; the tree's log-odds recalibrated by scale {a:.4}, offset {b:+.4}: winner log-loss {:.4}",
        decisive.len(),
        tree_loss / decisive.len() as f64
    );

    // Per delegator, per child routed to: positions, and each child's summed loss.
    let mut rows: Vec<Vec<(f64, Vec<f64>)>> = (0..bdt.node_count())
        .map(|idx| vec![(0.0, vec![0.0; bdt.children(idx).len()]); bdt.children(idx).len()])
        .collect();
    let mut oracle = vec![0.0; bdt.node_count()];
    for (pos, y) in &decisive {
        let mut idx = 0;
        while !bdt.children(idx).is_empty() {
            let children = bdt.children(idx);
            let leaves: Vec<usize> = children.iter().map(|&child| bdt.leaf_from(child, pos)).collect();
            let losses: Vec<f64> = leaves.iter().map(|&leaf| winner_loss(odds(leaf, pos), *y)).collect();
            let routed = bdt.leaf_from(idx, pos);
            let picked = leaves.iter().position(|&leaf| leaf == routed).expect("the routed leaf is under a child");
            let row = &mut rows[idx][picked];
            row.0 += 1.0;
            row.1.iter_mut().zip(&losses).for_each(|(sum, loss)| *sum += loss);
            oracle[idx] += losses[picked] - losses.iter().cloned().fold(f64::INFINITY, f64::min);
            idx = children[picked];
        }
    }
    for (idx, rows) in rows.iter().enumerate() {
        let n: f64 = rows.iter().map(|row| row.0).sum();
        if n == 0.0 {
            continue;
        }
        let regret: f64 = rows
            .iter()
            .enumerate()
            .filter(|(_, row)| row.0 > 0.0)
            .map(|(k, row)| row.1[k] - row.1.iter().cloned().fold(f64::INFINITY, f64::min))
            .sum();
        let children = bdt.children(idx).iter().map(|c| c.to_string()).collect::<Vec<_>>().join(" ");
        println!(
            "delegator {idx} (children {children}): {n} positions; regret {:.4} per position ({:.4} against each position's best child)",
            regret / n,
            oracle[idx] / n
        );
        for (k, row) in rows.iter().enumerate() {
            if row.0 == 0.0 {
                continue;
            }
            let cells: Vec<String> = row
                .1
                .iter()
                .enumerate()
                .map(|(j, sum)| if j == k { format!("[{:.4}]", sum / row.0) } else { format!("{:.4}", sum / row.0) })
                .collect();
            println!("  to {} ({:.1}%): {}", bdt.children(idx)[k], 100.0 * row.0 / n, cells.join(" "));
        }
    }

    // Near-duplicate leaves: mean absolute difference of their log-odds.
    let leaves: Vec<usize> = bdt.leaves().map(|(idx, _)| idx).collect();
    let mut sums = vec![0.0; leaves.len() * leaves.len()];
    let mut values = vec![0.0; leaves.len()];
    for (pos, _) in &data {
        values.iter_mut().zip(&leaves).for_each(|(v, &leaf)| *v = odds(leaf, pos));
        for i in 0..leaves.len() {
            for j in i + 1..leaves.len() {
                sums[i * leaves.len() + j] += (values[i] - values[j]).abs();
            }
        }
    }
    let mut pairs: Vec<(f64, usize, usize)> = (0..leaves.len())
        .flat_map(|i| (i + 1..leaves.len()).map(move |j| (i, j)))
        .map(|(i, j)| (sums[i * leaves.len() + j] / data.len() as f64, leaves[i], leaves[j]))
        .collect();
    pairs.sort_by(|x, y| x.0.total_cmp(&y.0));
    let shown: Vec<String> = pairs.iter().take(8).map(|(d, i, j)| format!("{i}-{j} {d:.3}")).collect();
    println!(
        "{} leaves, mean |log-odds difference| of a pair over {} positions {:.3}; closest: {}",
        leaves.len(),
        data.len(),
        pairs.iter().map(|p| p.0).sum::<f64>() / pairs.len().max(1) as f64,
        shown.join(", ")
    );
    Ok(())
}

fn calibration(model: &str, games: &Path, use_probs: bool) -> Result<()> {
    let model = LoadedModel::load(model, use_probs)?;
    let model = model.classifier();
    let data = games::read_labelled(games)?;
    let mut predictions = Vec::with_capacity(data.len());
    let mut out = [0.0; 3];
    for (pos, label) in &data {
        model.predict(pos, &mut out);
        let class = label.iter().position(|&l| l == 1.0).unwrap();
        predictions.push((out, class));
    }
    println!("{} positions from {}", data.len(), games.display());

    // Probability buckets: by decade of p below 0.5, by decade of 1 - p above.
    let bucket = |p: f64| -> i32 {
        let decade = |x: f64| (x.max(1e-300).log10().floor() as i32).max(-12);
        if p < 0.5 { decade(p) } else { -decade(1.0 - p) }
    };
    for (k, name) in ["white win", "black win", "draw"].iter().enumerate() {
        let mut buckets = std::collections::BTreeMap::<i32, (usize, f64, usize)>::new();
        for (p, class) in &predictions {
            let b = buckets.entry(bucket(p[k])).or_default();
            b.0 += 1;
            b.1 += p[k];
            b.2 += (*class == k) as usize;
        }
        println!("\nP({name}): predicted range | positions | mean predicted | actual");
        for (b, (n, sum, hits)) in buckets {
            let range = if b < 0 { format!("1e{b}..1e{}", b + 1) } else { format!("1-1e{}..1-1e{}", -b + 1, -b) };
            println!("  {range:>18} | {n:>8} | {:>12.3e} | {:.3e}", sum / n as f64, hits as f64 / n as f64);
        }
    }

    // Ratio calibration: predicted ln(P(white win) / P(black win)) against
    // the actual ln(white wins / black wins) in each bucket.
    let mut buckets = std::collections::BTreeMap::<i64, (usize, f64, usize, usize)>::new();
    for (p, class) in &predictions {
        let lo = chessai::player::log_odds(p[0], p[1]);
        let b = buckets.entry((lo / 2.0).floor() as i64).or_default();
        b.0 += 1;
        b.1 += lo;
        b.2 += (*class == 0) as usize;
        b.3 += (*class == 1) as usize;
    }
    println!("\nln(P(white win) / P(black win)): range | positions | mean predicted | actual ln(W/B) (W, B)");
    for (b, (n, sum, w, l)) in buckets {
        let actual = if w > 0 && l > 0 { format!("{:+.2}", (w as f64 / l as f64).ln()) } else { "-".into() };
        println!("  {:+4}..{:+4} | {n:>8} | {:+8.2} | {actual} ({w}, {l})", 2 * b, 2 * b + 2, sum / n as f64);
    }
    Ok(())
}

/// `routed`: a delegation model and one of its leaves; only the positions it
/// routes to that leaf are scored.
fn eval_loss(
    model: &str,
    games: &Path,
    use_probs: bool,
    fit: bool,
    calibration: Option<&str>,
    routed: Option<(&str, usize)>,
) -> Result<()> {
    let model = LoadedModel::load(model, use_probs)?;
    let model = model.classifier();
    let mut data = games::read_labelled(games)?;
    if let Some((spec, leaf)) = routed {
        let router = LoadedModel::load(spec, use_probs)?;
        data.retain(|(pos, _)| router.leaf(pos) == leaf);
    }
    let (mut log, mut abs, mut decisive, mut winner_log) = (0.0, 0.0, 0usize, 0.0);
    let mut out = [0.0; 3];
    for (pos, label) in &data {
        model.predict(pos, &mut out);
        log += delegation::log_loss(&out, label);
        abs += 1.0 - out.iter().zip(label).map(|(p, l)| p * l).sum::<f64>();
        if label[2] == 0.0 {
            let winner = if label[0] == 1.0 { 0 } else { 1 };
            let p = out[winner] / (out[0] + out[1]).max(f64::MIN_POSITIVE);
            winner_log += -p.max(f64::MIN_POSITIVE).ln();
            decisive += 1;
        }
    }
    let n = data.len() as f64;
    println!(
        "{} positions: log-loss {:.4}, abs error {:.4}; {decisive} decisive: winner log-loss {:.4}",
        data.len(),
        log / n,
        abs / n,
        winner_log / decisive.max(1) as f64
    );

    if fit || calibration.is_some() {
        let logs: Vec<([f64; 3], usize)> = data
            .iter()
            .map(|(pos, label)| {
                let mut l = [0.0; 3];
                model.predict_log(pos, &mut l);
                (l, label.iter().position(|&x| x == 1.0).unwrap())
            })
            .collect();
        let report = |name: &str, cal: Calibration| {
            let (mut decisive, mut winner_log) = (0usize, 0.0);
            for (l, class) in &logs {
                if *class < 2 {
                    let p = cal.probs(l);
                    winner_log += -(p[*class] / (p[0] + p[1])).max(f64::MIN_POSITIVE).ln();
                    decisive += 1;
                }
            }
            println!(
                "{name} calibration {cal}: log-loss {:.4}, winner log-loss {:.4}",
                cal.log_loss(&logs),
                winner_log / decisive.max(1) as f64
            );
        };
        if let Some(c) = calibration {
            report("given", Calibration::parse(c)?);
        }
        if fit {
            report("fitted", Calibration::fit(&logs));
        }
    }
    Ok(())
}

/// Plays `game` to the end with `player` on both sides; returns the result.
fn play_out(mut game: Game, player: Player, rng: &mut StdRng) -> GameResult {
    loop {
        if let Some(result) = game.result() {
            return result;
        }
        let pos = game.position();
        let candidates = player::candidates(pos);
        let chosen = player::select(player, pos.turn(), &candidates, rng);
        game.play(candidates[chosen].mv);
    }
}

fn rank_test(
    source: &str,
    models: &[String],
    positions: usize,
    playouts: usize,
    playout_policy: Policy,
    seed: u64,
    use_probs: bool,
) -> Result<()> {
    use rayon::prelude::*;
    let source = LoadedModel::load(source, use_probs)?;
    let player = source.player(playout_policy, 0.1, 0);

    // Sample positions at a random ply of games played by the source.
    let mut rng = StdRng::seed_from_u64(seed);
    let mut sampled = Vec::new();
    while sampled.len() < positions {
        let target = rng.random_range(10..150);
        let mut game = Game::default();
        for _ in 0..target {
            if game.result().is_some() {
                break;
            }
            let pos = game.position();
            let candidates = player::candidates(pos);
            let chosen = player::select(player, pos.turn(), &candidates, &mut rng);
            game.play(candidates[chosen].mv);
        }
        if game.result().is_none() && game.position().legal_moves().len() > 1 {
            sampled.push(game);
        }
    }

    // Value every legal move by playouts, from the point of view of the side
    // to move: win 1, draw 1/2, loss 0. Returns (mean, variance) per move.
    let tasks: Vec<(usize, usize)> = sampled
        .iter()
        .enumerate()
        .flat_map(|(p, g)| (0..g.position().legal_moves().len()).map(move |m| (p, m)))
        .collect();
    let values: Vec<(f64, f64)> = tasks
        .par_iter()
        .map(|&(p, m)| {
            let game = &sampled[p];
            let mover = game.position().turn();
            let mv = game.position().legal_moves()[m];
            let mut rng = StdRng::seed_from_u64(selfplay::derive_seed(seed, p as u64, m as u64));
            let scores: Vec<f64> = (0..playouts)
                .map(|_| {
                    let mut g = game.clone();
                    g.play(mv);
                    match play_out(g, player, &mut rng) {
                        GameResult::Draw => 0.5,
                        GameResult::WhiteWin if mover.is_white() => 1.0,
                        GameResult::BlackWin if mover.is_black() => 1.0,
                        _ => 0.0,
                    }
                })
                .collect();
            let mean = scores.iter().sum::<f64>() / playouts as f64;
            let var = scores.iter().map(|s| (s - mean).powi(2)).sum::<f64>() / playouts as f64;
            (mean, var)
        })
        .collect();

    let mut by_position = vec![Vec::new(); sampled.len()];
    for (&(p, _), &v) in tasks.iter().zip(&values) {
        by_position[p].push(v);
    }
    let decided_pairs: usize = by_position
        .iter()
        .map(|vs| {
            let mut n = 0;
            for i in 0..vs.len() {
                for j in i + 1..vs.len() {
                    if (vs[i].0 - vs[j].0).abs() > 2.0 * ((vs[i].1 + vs[j].1) / playouts as f64).sqrt() {
                        n += 1;
                    }
                }
            }
            n
        })
        .sum();
    println!(
        "{} positions, {} moves, {playouts} playouts each with {playout_policy:?}; {decided_pairs} move pairs whose playout values differ by > 2 standard errors",
        sampled.len(),
        tasks.len()
    );

    for name in models {
        let model = LoadedModel::load(name, use_probs)?;
        let model = model.classifier();
        let (mut agree, mut pairs, mut regret) = (0usize, 0usize, 0.0);
        let mut out = [0.0; 3];
        for (game, vs) in sampled.iter().zip(&by_position) {
            let pos = game.position();
            let (win, loss) = if pos.turn().is_white() { (0, 1) } else { (1, 0) };
            let scores: Vec<f64> = player::candidates(pos)
                .iter()
                .map(|c| {
                    model.predict(&c.position, &mut out);
                    player::log_odds(out[win], out[loss])
                })
                .collect();
            for i in 0..vs.len() {
                for j in i + 1..vs.len() {
                    if (vs[i].0 - vs[j].0).abs() > 2.0 * ((vs[i].1 + vs[j].1) / playouts as f64).sqrt() {
                        pairs += 1;
                        if (scores[i] - scores[j]) * (vs[i].0 - vs[j].0) > 0.0 {
                            agree += 1;
                        }
                    }
                }
            }
            let best = vs.iter().map(|v| v.0).fold(f64::NEG_INFINITY, f64::max);
            let top = scores.iter().enumerate().max_by(|a, b| a.1.total_cmp(b.1)).unwrap().0;
            regret += best - vs[top].0;
        }
        println!(
            "{name}: pairwise agreement {:.1}% of {pairs}, top-move regret {:.4}",
            100.0 * agree as f64 / pairs.max(1) as f64,
            regret / sampled.len() as f64
        );
    }
    Ok(())
}

fn sorted_uci(pos: &Chess) -> String {
    let mut moves: Vec<String> = pos
        .legal_moves()
        .iter()
        .map(|m| m.to_uci(CastlingMode::Standard).to_string())
        .collect();
    moves.sort();
    moves.join(" ")
}

#[derive(Default)]
struct Mismatches {
    count: usize,
    examples: Vec<String>,
}

impl Mismatches {
    fn add(&mut self, example: String) {
        self.count += 1;
        if self.examples.len() < 3 {
            self.examples.push(example);
        }
    }

    fn report(&self, name: &str) {
        println!("{name}: {}", self.count);
        for e in &self.examples {
            println!("    {e}");
        }
    }
}

fn xcheck(file: PathBuf) -> Result<()> {
    let text = std::fs::read_to_string(&file).with_context(|| format!("reading {file:?}"))?;

    let mut game = Game::default();
    let (mut positions, mut games_checked) = (0, 0);
    let mut legal_moves = Mismatches::default();
    let mut encodings = Mismatches::default();
    let mut castling_flags = Mismatches::default();
    let mut rust_ended_early = Mismatches::default();
    let mut results = Mismatches::default();
    let mut illegal_played = Mismatches::default();
    // After python plays a move rust considers illegal the positions no
    // longer correspond, so the rest of that game is skipped.
    let mut desynced = false;

    for (n, line) in text.lines().enumerate() {
        let fen = || shakmaty::fen::Fen::from_position(game.position(), shakmaty::EnPassantMode::Legal);

        if let Some(python_result) = line.strip_prefix("end ") {
            if desynced {
                game = Game::default();
                desynced = false;
                continue;
            }
            let rust_result = game.result().map_or("none", |r| r.pgn());
            if rust_result != python_result {
                results.add(format!("line {}: python {python_result}, rust {rust_result} at {}", n + 1, fen()));
            }
            game = Game::default();
            games_checked += 1;
            desynced = false;
            continue;
        }

        if desynced {
            continue;
        }

        let parts: Vec<&str> = line.split(" | ").collect();
        let [python_legal, python_enc, played] = parts[..] else {
            bail!("line {}: expected 3 fields separated by ' | '", n + 1);
        };
        positions += 1;

        let rust_legal = sorted_uci(game.position());
        if rust_legal != python_legal {
            legal_moves.add(format!(
                "line {}: {}\n      python: {python_legal}\n      rust:   {rust_legal}",
                n + 1,
                fen()
            ));
        }

        let python_enc = games::parse_position(python_enc)?;
        let rust_enc = encoding::encode(game.position());
        if rust_enc != python_enc {
            let differ: Vec<usize> = (0..rust_enc.len()).filter(|&i| rust_enc[i] != python_enc[i]).collect();
            let example = format!("line {}: features {differ:?} differ at {}", n + 1, fen());
            if differ.iter().all(|&i| (66..70).contains(&i)) {
                castling_flags.add(example);
            } else {
                encodings.add(example);
            }
        }

        if let Some(r) = game.result() {
            rust_ended_early.add(format!("line {}: rust says {} at {}", n + 1, r.pgn(), fen()));
        }

        let uci = played
            .parse::<UciMove>()
            .with_context(|| format!("line {}: bad move {played}", n + 1))?;
        match uci.to_move(game.position()) {
            Ok(m) => game.play(m),
            Err(_) => {
                illegal_played.add(format!("line {}: python played {played} at {}", n + 1, fen()));
                desynced = true;
            }
        }
    }

    println!("checked {positions} positions in {games_checked} games\n");
    illegal_played.report("python played a move rust considers illegal (rest of game skipped)");
    legal_moves.report("legal move set differs");
    encodings.report("encoding differs (other than castling flags)");
    castling_flags.report("castling flags differ (known: python keeps the flag after the rook is captured)");
    rust_ended_early.report("rust says game over, python continued");
    results.report("final result differs");

    if legal_moves.count + encodings.count + illegal_played.count > 0 {
        bail!("move generation or encoding mismatches found");
    }
    Ok(())
}

fn bench_movegen(game_num: usize, seed: u64) -> Result<()> {
    let mut rng = StdRng::seed_from_u64(seed);
    let mut plies = 0;
    let mut checksum = 0u64;
    let start = Instant::now();

    for _ in 0..game_num {
        let mut game = Game::default();
        while game.result().is_none() {
            let moves = game.position().legal_moves();
            for &m in &moves {
                let mut next = game.position().clone();
                next.play_unchecked(m);
                let enc: Encoded = encoding::encode(&next);
                checksum = checksum.wrapping_add(enc[0] as u64);
            }
            game.play(moves[rng.random_range(0..moves.len())]);
            plies += 1;
        }
    }

    let secs = start.elapsed().as_secs_f64();
    println!(
        "{game_num} games, {plies} plies in {secs:.2}s ({:.0} plies/s) [checksum {checksum}]",
        plies as f64 / secs
    );
    Ok(())
}

fn bench_classifier<C: Classifier>(
    name: &str,
    new_model: impl Fn() -> C,
    games_dir: &Path,
    model_out: &Path,
    predictions_out: &Path,
    reps: usize,
) -> Result<()> {
    let data = games::read_labelled(games_dir).with_context(|| format!("reading {games_dir:?}"))?;

    let mut model = new_model();
    let start = Instant::now();
    for _ in 0..reps {
        model = new_model();
        for (pos, label) in &data {
            model.train(pos, label);
        }
        model.refresh();
    }
    let train_secs = start.elapsed().as_secs_f64() / reps as f64;
    model.save(model_out)?;

    let mut out = vec![[0.0; 3]; data.len()];
    let start = Instant::now();
    for _ in 0..reps {
        for ((pos, _), o) in data.iter().zip(out.iter_mut()) {
            model.predict(pos, o);
        }
    }
    let predict_secs = start.elapsed().as_secs_f64() / reps as f64;

    let mut text = String::new();
    for o in &out {
        writeln!(text, "{:e} {:e} {:e}", o[0], o[1], o[2])?;
    }
    std::fs::write(predictions_out, text)?;

    let n = data.len() as f64;
    println!(
        "rust {name}: {} positions, train {:.2}M pos/s, predict {:.2}M pos/s",
        data.len(),
        n / train_secs / 1e6,
        n / predict_secs / 1e6
    );
    Ok(())
}

struct SelfPlayRun {
    out: PathBuf,
    rounds: u64,
    games: usize,
    policy: Policy,
    temperature: f64,
    seed: u64,
    vs_previous: bool,
    no_games: bool,
    depth: u32,
    label_depth: Option<u32>,
    label_result: f64,
    label_model: Option<LoadedModel>,
    round_forget: f64,
    age_forget: f64,
    keep_states: u64,
}

impl SelfPlayRun {
    /// Plays and trains rounds `start..rounds`; `previous` is the version
    /// before `model`, the opponent with `vs_previous`.
    fn run<M: Classifier + Sync + Clone>(&self, name: &str, mut model: M, mut previous: M, start: u64) -> Result<()> {
        std::fs::create_dir_all(&self.out)?;
        println!(
            "self-play: {name}, {} rounds of {} games, {}policy {:?}{}, seed {}, {} threads",
            self.rounds,
            self.games,
            if self.vs_previous { "version N vs N-1, " } else { "" },
            self.policy,
            if self.depth > 0 { format!(", search depth {}", self.depth) } else { String::new() }
                + &match self.label_depth {
                    Some(depth) => format!(
                        ", labels from depth-{depth} search by {} with result weight {}",
                        if self.label_model.is_some() { "a fixed model" } else { "the model" },
                        self.label_result
                    ),
                    None => String::new(),
                },
            self.seed,
            rayon::current_num_threads()
        );

        let ladder_path = self.out.join("ladder.csv");
        if self.vs_previous && start == 0 {
            std::fs::write(&ladder_path, "round,version,opponent,wins,losses,draws,score,elo,elo_low,elo_high\n")?;
        }
        if start > 0 {
            println!("resuming at round {start}");
        } else {
            self.save_state(&model, name, 0)?;
        }

        for round in start..self.rounds {
            let start = Instant::now();
            let player = |model| Player { depth: self.depth, ..Player::new(model, self.policy, self.temperature) };
            let records = if self.vs_previous {
                let (current, opponent) = (player(&model), player(&previous));
                selfplay::play_match(current, opponent, self.games, selfplay::derive_seed(self.seed, round, 0))
            } else {
                selfplay::play_round(player(&model), self.games, self.seed, round)
            };
            let play_secs = start.elapsed().as_secs_f64();

            if self.vs_previous {
                let m = selfplay::score_match(&records);
                let opponent = round.saturating_sub(1);
                let mut ladder = std::fs::OpenOptions::new().append(true).open(&ladder_path)?;
                std::io::Write::write_all(
                    &mut ladder,
                    format!(
                        "{round},{round},{opponent},{},{},{},{:.4},{:.1},{:.1},{:.1}\n",
                        m.wins, m.losses, m.draws, m.score, m.elo, m.elo_low, m.elo_high
                    )
                    .as_bytes(),
                )?;
                println!(
                    "round {round}: v{round} vs v{opponent}: +{} -{} ={}, score {:.1}%, Elo {:+.0} ({:+.0} to {:+.0})",
                    m.wins,
                    m.losses,
                    m.draws,
                    100.0 * m.score,
                    m.elo,
                    m.elo_low,
                    m.elo_high
                );
                previous = model.clone();
            }

            if !self.no_games {
                selfplay::write_round(&self.out.join(format!("round{round}")), &records)?;
            }
            let count = |r: GameResult| records.iter().filter(|g| g.result == r).count();
            let (w, b, d) = (count(GameResult::WhiteWin), count(GameResult::BlackWin), count(GameResult::Draw));
            let mut results = std::fs::OpenOptions::new().create(true).append(true).open(self.out.join("results.txt"))?;
            std::io::Write::write_all(
                &mut results,
                format!("round {round} white wins: {w} black wins: {b} draws: {d}\n").as_bytes(),
            )?;

            let labels = if let Some(depth) = self.label_depth {
                let start = Instant::now();
                let labeller = self.label_model.as_ref().map_or(&model as &(dyn Classifier + Sync), |m| m.classifier());
                let calibration = selfplay::fit_calibration(&records, labeller);
                let labels = selfplay::search_labels(&records, labeller, calibration, depth, self.label_result);
                println!(
                    "round {round}: calibration {calibration}, labels {:.2}s",
                    start.elapsed().as_secs_f64()
                );
                labels
            } else {
                selfplay::result_labels(&records)
            };
            let start = Instant::now();
            model.observe_games(&records.iter().map(|r| r.positions.as_slice()).collect::<Vec<_>>());
            let data = selfplay::training_data(&records, &labels, self.seed, round);
            for (pos, label, game) in &data {
                model.train_in_game(pos, label, *game);
            }
            if self.round_forget != 1.0 {
                model.forget(self.round_forget);
            }
            if self.age_forget != 0.0 {
                model.forget(((round + 2) as f64 / (round + 1) as f64).powf(self.age_forget));
            }
            model.refresh();
            let train_secs = start.elapsed().as_secs_f64();
            model.save(&self.out.join(format!("{name}{}.model", round + 1)))?;
            self.save_state(&model, name, round + 1)?;

            println!(
                "round {round}: +{w} -{b} ={d}, {} plies, play {play_secs:.2}s ({:.0} plies/s), train {train_secs:.2}s",
                data.len(),
                data.len() as f64 / play_secs
            );
            if let Some(warning) = selfplay::duplicate_warning(&records) {
                println!("  {warning}");
            }
        }
        Ok(())
    }

    /// Saves version `v`'s training state, if the model keeps any beyond its
    /// model file (see `state`), and deletes the state --keep-states drops.
    fn save_state<M: Classifier>(&self, model: &M, name: &str, v: u64) -> Result<()> {
        if model.save_state(&self.out.join(format!("{name}{v}.state")))?
            && self.keep_states > 0
            && v >= self.keep_states
        {
            match std::fs::remove_file(self.out.join(format!("{name}{}.state", v - self.keep_states))) {
                Err(e) if e.kind() != std::io::ErrorKind::NotFound => return Err(e.into()),
                _ => {}
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn game(moves: &[&str]) -> Game {
        let mut game = Game::default();
        for uci in moves {
            let m = uci.parse::<UciMove>().unwrap().to_move(game.position()).unwrap();
            game.play(m);
        }
        game
    }

    /// The moves `player` chooses in the game's position over 200 seeds, by
    /// their index in `legal_moves()`.
    fn choices(player: Player, game: &Game) -> Vec<usize> {
        let candidates = player::candidates(game.position());
        (0..200).map(|seed| player::choose(player, game, &candidates, &mut StdRng::seed_from_u64(seed))).collect()
    }

    fn index_of(game: &Game, uci: &str) -> usize {
        let m = uci.parse::<UciMove>().unwrap().to_move(game.position()).unwrap();
        game.position().legal_moves().iter().position(|&l| l == m).unwrap()
    }

    #[test]
    fn random_players_search_like_the_others() {
        let random = LoadedModel::Uniform(Uniform);
        // Black to move can mate with Qh4#: at depth 1 it always does, with
        // the tournament's policy or the arena's.
        let g = game(&["f2f3", "e7e5", "g2g4"]);
        let mate = index_of(&g, "d8h4");
        for policy in [Policy::LogOddsSoftmax, Policy::WldScoreJitter10] {
            assert!(choices(random.player(policy, 0.1, 1), &g).iter().all(|&c| c == mate));
        }
        // Without search it plays at random, as before.
        assert!(choices(random.player(Policy::LogOddsSoftmax, 0.1, 0), &g).iter().any(|&c| c != mate));
        // At depth 2 it never lets Black mate (g2g4), but otherwise picks
        // moves at random.
        let g = game(&["f2f3", "e7e5"]);
        let picked = choices(random.player(Policy::LogOddsSoftmax, 0.1, 2), &g);
        assert!(!picked.contains(&index_of(&g, "g2g4")));
        assert!(picked.iter().collect::<std::collections::HashSet<_>>().len() > 5);
    }
}
